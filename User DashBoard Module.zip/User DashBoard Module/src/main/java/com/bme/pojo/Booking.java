package com.bme.pojo;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="booking")
public class Booking {
	
	@Id
	@GeneratedValue
	@Column(name="booking_id")
	private int bookingId;
	
	@Column(name="user_id")
	private int userId;
	
	@Column(name="event_id")
	private int eventId;
	
	@Column (name="transaction_id")
	private int transactionId;
	
	@Column(name="amount_paid")
	private double amountPaid;
	
	@Column (name="create_date")
	private Date createDate;
	
	@Column (name="delete_date")
	private Date deleteDate;
	
	@Column(name="no_of_tickets")
	private int noOfTickets;

	
	public Booking() {
		super();
	}

	public Booking(int bookingId, int userId, int eventId, int transactionId,
			double amountPaid, Date createDate, Date deleteDate, int noOfTickets) {
		super();
		this.bookingId = bookingId;
		this.userId = userId;
		this.eventId = eventId;
		this.transactionId = transactionId;
		this.amountPaid = amountPaid;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.noOfTickets = noOfTickets;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public int getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}
	
	
	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", userId=" + userId
				+ ", eventId=" + eventId + ", transactionId=" + transactionId
				+ ", amountPaid=" + amountPaid + ", createDate=" + createDate
				+ ", deleteDate=" + deleteDate + ", noOfTickets=" + noOfTickets
				+ "]";
	}



}
