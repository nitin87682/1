package com.bme.pojo;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



	@Entity
	@Table(name="event1")
	public class Event1 {

		@Id
		
	    @Column(name="event_id")
		private int eventId;
		  @Column(name="event_name")
		private String eventName;
		  @Column(name="event_date")
		private java.sql.Date eventDate;
		  
		  
		  
		public Event1() {
			super();
		}
		public Event1(int eventId, String eventName, Date eventDate) {
			super();
			this.eventId = eventId;
			this.eventName = eventName;
			this.eventDate = eventDate;
		}
		public int getEventId() {
			return eventId;
		}
		public void setEventId(int eventId) {
			this.eventId = eventId;
		}
		public String getEventName() {
			return eventName;
		}
		public void setEventName(String eventName) {
			this.eventName = eventName;
		}
		public java.sql.Date getEventDate() {
			return eventDate;
		}
		public void setEventDate(java.sql.Date eventDate) {
			this.eventDate = eventDate;
		}
		@Override
		public String toString() {
			return "Event1 [eventId=" + eventId + ", eventName=" + eventName
					+ ", eventDate=" + eventDate + "]";
		}
	
	
	
	

}
