package com.bme.pojo;

import java.sql.Time;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="event")
public class Event {

	@Id
	@GeneratedValue
    @Column(name="event_id")
	private int eventId;
	
	 @Column(name="event_name")
	private String eventName;
	 
	  @Column(name="event_date")
	private java.sql.Date eventDate;
	  
	  @Column(name="event_certificate")
	  private String eventCertificate;
	  
	  @Column(name="event_description")
	  private String eventDescription;
	  
	  @Column(name="capacity_id")
	  private int capacityId;
	  
	  @Column(name="event_status")
	  private String eventStatus;
	  
	  @Column(name="event_time")
	  private Time eventTime;
	  
	  
	  @Column(name="organiser_id")
	  private int organiserId;
	  
	  @Column(name="price_id")
	  private int priceId;
	  
	  @Column(name="venue_id")
	  private int venueId;
	  
	  @Column(name="performer_id")
	  private int performerId;
	  
	  @Column(name="category_id")
	  private int categoryId;
	  
	  @Column(name="create_date")
		private java.sql.Date createDate;
	  

	  @Column(name="delete_date")
			private java.sql.Date deleteDate;


	  @Column(name="event_image_url")
	  private String eventImageUrl;
	  
	  

	public Event() {
		super();
	}



	public Event(int eventId, String eventName, java.sql.Date eventDate,
			String eventCertificate, String eventDescription, int capacityId,
			String eventStatus, Time eventTime, int organiserId, int priceId,
			int venueId, int performerId, int categoryId,
			java.sql.Date createDate, java.sql.Date deleteDate,
			String eventImageUrl) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.eventDate = eventDate;
		this.eventCertificate = eventCertificate;
		this.eventDescription = eventDescription;
		this.capacityId = capacityId;
		this.eventStatus = eventStatus;
		this.eventTime = eventTime;
		this.organiserId = organiserId;
		this.priceId = priceId;
		this.venueId = venueId;
		this.performerId = performerId;
		this.categoryId = categoryId;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.eventImageUrl = eventImageUrl;
	}



	public int getEventId() {
		return eventId;
	}



	public void setEventId(int eventId) {
		this.eventId = eventId;
	}



	public String getEventName() {
		return eventName;
	}



	public void setEventName(String eventName) {
		this.eventName = eventName;
	}



	public java.sql.Date getEventDate() {
		return eventDate;
	}



	public void setEventDate(java.sql.Date eventDate) {
		this.eventDate = eventDate;
	}



	public String getEventCertificate() {
		return eventCertificate;
	}



	public void setEventCertificate(String eventCertificate) {
		this.eventCertificate = eventCertificate;
	}



	public String getEventDescription() {
		return eventDescription;
	}



	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}



	public int getCapacityId() {
		return capacityId;
	}



	public void setCapacityId(int capacityId) {
		this.capacityId = capacityId;
	}



	public String getEventStatus() {
		return eventStatus;
	}



	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}



	public Time getEventTime() {
		return eventTime;
	}



	public void setEventTime(Time eventTime) {
		this.eventTime = eventTime;
	}



	public int getOrganiserId() {
		return organiserId;
	}



	public void setOrganiserId(int organiserId) {
		this.organiserId = organiserId;
	}



	public int getPriceId() {
		return priceId;
	}



	public void setPriceId(int priceId) {
		this.priceId = priceId;
	}



	public int getVenueId() {
		return venueId;
	}



	public void setVenueId(int venueId) {
		this.venueId = venueId;
	}



	public int getPerformerId() {
		return performerId;
	}



	public void setPerformerId(int performerId) {
		this.performerId = performerId;
	}



	public int getCategoryId() {
		return categoryId;
	}



	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}



	public java.sql.Date getCreateDate() {
		return createDate;
	}



	public void setCreateDate(java.sql.Date createDate) {
		this.createDate = createDate;
	}



	public java.sql.Date getDeleteDate() {
		return deleteDate;
	}



	public void setDeleteDate(java.sql.Date deleteDate) {
		this.deleteDate = deleteDate;
	}



	public String getEventImageUrl() {
		return eventImageUrl;
	}



	public void setEventImageUrl(String eventImageUrl) {
		this.eventImageUrl = eventImageUrl;
	}



	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eventName=" + eventName
				+ ", eventDate=" + eventDate + ", eventCertificate="
				+ eventCertificate + ", eventDescription=" + eventDescription
				+ ", capacityId=" + capacityId + ", eventStatus=" + eventStatus
				+ ", eventTime=" + eventTime + ", organiserId=" + organiserId
				+ ", priceId=" + priceId + ", venueId=" + venueId
				+ ", performerId=" + performerId + ", categoryId=" + categoryId
				+ ", createDate=" + createDate + ", deleteDate=" + deleteDate
				+ ", eventImageUrl=" + eventImageUrl + "]";
	}


	
}



