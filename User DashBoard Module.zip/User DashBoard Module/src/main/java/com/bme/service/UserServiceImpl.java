package com.bme.service;

import java.util.ArrayList;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bme.dao.UserDao;
import com.bme.pojo.User;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao userDao;
	
	@Transactional
	public void saveUser(User user) {
		userDao.saveUser(user);
	}

	@Transactional
	public List<User> getAllUsers() {
		
		return userDao.getAllUsers();
	}

	@Transactional
	public void deleteUser(Integer employeeId) {
		userDao.deleteUser(employeeId);
	}

	@Transactional
	public User searchUser(Integer userId) {
		
		return userDao.searchUser(userId);
	}

	@Transactional
	public void savePassword(User user, String current) {
		userDao.savePassword(user, current);
	}

	@Transactional
	public List<Object> getUserBookingHistory(Integer userId) {
		return userDao.getUserBookingHistory(userId);
		
	}

	@Transactional
	public List<Object> userEvents(Integer userId) {
		return userDao.userEvents(userId);
	}

}
