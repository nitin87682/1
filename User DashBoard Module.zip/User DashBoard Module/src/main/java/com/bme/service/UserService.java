package com.bme.service;

import java.util.ArrayList;
import java.util.List;


import com.bme.pojo.User;

public interface UserService {
	public void saveUser(User user);
	public List<User> getAllUsers();
	public void deleteUser(Integer userId);
	public User searchUser(Integer UserId);
	public void savePassword(User user, String current);
	public List<Object> getUserBookingHistory(Integer userId);
	public List<Object> userEvents(Integer userId);
	
}
