package com.bme.controller;

import java.text.SimpleDateFormat;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bme.pojo.User;
import com.bme.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	private User searchuser=null;

	@RequestMapping("/userForm")
	public String showUserForm(Map<String, Object> maps){
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		List<User> users=userService.getAllUsers();
		maps.put("users",users);
		maps.put("userSearch",searchuser);
		maps.put("user",new User());
		
		if(searchuser!=null){
		maps.put("user", searchuser);
		//Date userDob=searchuser.getDate_of_birth();
	
			/*if(userDob!=null)
			{		
					String dob=myFormat.format(userDob);
					maps.put("userdob", dob);
			}*/
			
		}
		 return "user";
	}
	
	
	@RequestMapping(value={"/showUser","/updateUser"},method=RequestMethod.POST)
	public String showEmpDetails(Map<String, Object> map,
			@Valid @ModelAttribute("user") User user, BindingResult result){
		List<User> users=userService.getAllUsers();
		System.out.println("update");
		System.out.println(users);
		
		map.put("users",users);
		map.put("userSearch",searchuser);
	
		if(result.hasErrors()){
			//System.out.println("Search Object:" + searchUser);
			//System.out.println(result);
			return "user";
		}
		else{
			searchuser=null;
			userService.saveUser(user);
			System.out.println("User values Updated");
			return "redirect:/userForm";
		}
	}
	
	
	
	@RequestMapping("/deleteUser/{userId}")
	public String deleteUser(@PathVariable("userId") Integer userId){
		userService.deleteUser(userId);
		System.out.println("User deleted");
		return "redirect:/userForm";
	}
	
	@RequestMapping("/updateUser/{userId}")
	public String  updateUser(@PathVariable("userId") Integer userId){
		User user=userService.searchUser(userId);
		searchuser=user;
		System.out.println(user);
		return"redirect:/userForm";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//========================================Update Password===================
	
	
	
	@RequestMapping("/passwordForm")
	public String showPasswordForm(Map<String, Object> maps){
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		List<User> users=userService.getAllUsers();
		
		maps.put("users",users);
		maps.put("userSearch",searchuser);
		maps.put("user",new User());
		if(searchuser!=null){
		maps.put("user", searchuser);
		Date userDob=searchuser.getDate_of_birth();
	
			/*if(userDob!=null)
			{		
					String dob=myFormat.format(userDob);
					maps.put("userdob", dob);
			}*/
			
		}
		 return "changePassword";
	}
		
	
	
	@RequestMapping(value={"/updatePassword/{user}"},method=RequestMethod.POST)
	public String showUpdatePassword(Map<String, Object> map,
			@Valid @ModelAttribute("user") User user, BindingResult result){
		
		List<User> users=userService.getAllUsers();

		map.put("users",users);
		map.put("userSearch",searchuser);
	
		if(result.hasErrors()){
			//System.out.println("Search Object:" + searchUser);
			//System.out.println(result);
			return "user";
		}
		else{
			searchuser=null;
			
			userService.saveUser(user);
			return "redirect:/userForm";
		}
	}
		
	@RequestMapping("/updatePassword/{userId}")
	public String  updateUserPassword(@PathVariable("userId") Integer userId){
		User user=userService.searchUser(userId);
		searchuser=user;
		
		return"redirect:/passwordForm";
	}
	
	
	//========================================Booking History===================
	
	
	
/*	@RequestMapping("/bookingHistory1/{userId}")
	public String bookingHistory(@PathVariable("userId")Integer userId)
	{
		List<Object> userHistory=userService.getUserBookingHistory(userId);
		
		JSONObject json = new JSONObject(userHistory);
		try {
			json.put("userHistory",userHistory);
			System.out.println(json);
		} catch (JSONException e) {
			
			e.printStackTrace();
		}
		
	
		return"redirect:/bookingHistory";
		
 
		
	}
	*/
	

	
	
	@RequestMapping("/bookingHistory/{userId}")
	public String showBooking(Map<String, Object> maps,@PathVariable("userId")Integer userId){
		
		System.out.println(userId);
		List<Object> users=userService.getUserBookingHistory(userId);
		JSONObject json = new JSONObject(users);
		try {
			json.put("userHistory",users);
			System.out.println(json);
		} catch (JSONException e) {
			
			e.printStackTrace();
		}
		maps.put("users",json);
		maps.put("userSearch",searchuser);
		maps.put("json",new User());
		
		
		
		
		
		
		if(searchuser!=null){
		maps.put("user", searchuser);
		//Date userDob=searchuser.getDate_of_birth();
	
			/*if(userDob!=null)
			{		
					String dob=myFormat.format(userDob);
					maps.put("userdob", dob);
			}*/
			
		}
		 return "bookingHistory";
	}
	
	
	
	
	
	
	
	
	
	
	//======================Upload Image==========================

	
	
	@RequestMapping("/uploadImage/{userId}")
	public String  uploadImage(@PathVariable("userId") Integer userId){
		User user=userService.searchUser(userId);
		searchuser=user;
		
		return"redirect:/image";
	}
	
	
	
	

	@RequestMapping("/image")
	public String image(Map<String, Object> maps){
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		List<User> users=userService.getAllUsers();
		maps.put("users",users);
		maps.put("userSearch",searchuser);
		maps.put("user",new User());
		
		if(searchuser!=null){
		maps.put("user", searchuser);
		Date userDob=searchuser.getDate_of_birth();
	
			/*if(userDob!=null)
			{		
					String dob=myFormat.format(userDob);
					maps.put("userdob", dob);
			}*/
			
		}
		 return "uploadImage";
	}
	
	
	@RequestMapping(value={"/updateImage/{user}"},method=RequestMethod.POST)
	public String UpdateImage(Map<String, Object> map,
			@Valid @ModelAttribute("user") User user, BindingResult result){
		List<User> users=userService.getAllUsers();
		System.out.println(user.getPassword());
		System.out.println(user.getUserId());
		map.put("users",users);
		map.put("userSearch",searchuser);
	
		if(result.hasErrors()){
			//System.out.println("Search Object:" + searchUser);
			//System.out.println(result);
			return "user";
		}
		else{
			searchuser=null;
			userService.saveUser(user);
			return "redirect:/userForm";
		}
	}
	
	
	//===========================Upcoming Events=========================
	
	
	
	

	
	
	
	@RequestMapping("/upcomingEvents/{userId}")
	public String showEvents(Map<String, Object> maps,@PathVariable("userId")Integer userId){
		
		System.out.println(userId);
		List<Object> users=userService.userEvents(userId);
		JSONObject json = new JSONObject(users);
		try {
			json.put("userHistory",users);
			System.out.println(json);
		} catch (JSONException e) {
			
			e.printStackTrace();
		}
		maps.put("users",json);
		maps.put("userSearch",searchuser);
		maps.put("json",new User());
		
		
		
		
		
		
		if(searchuser!=null){
		maps.put("user", searchuser);
		//Date userDob=searchuser.getDate_of_birth();
	
			/*if(userDob!=null)
			{		
					String dob=myFormat.format(userDob);
					maps.put("userdob", dob);
			}*/
			
		}
		 return "userEvents";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

	
}