package com.bme.dao;

import java.util.ArrayList;

import java.util.Date;

import java.util.List;

import javax.persistence.EntityManager;



import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bme.pojo.Booking;
import com.bme.pojo.Event;
import com.bme.pojo.User;

@Repository
public class UserDaoImpl implements UserDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void saveUser(User user) {

		user.setCreateDate(new Date());
		user.setActivationStatus("activated");
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}

	@Override
	public List<User> getAllUsers() {
		
		return sessionFactory.getCurrentSession().createQuery("from User").list();
	}

	@Override
	public void deleteUser(Integer userId) {
		User user=(User) sessionFactory.getCurrentSession().get(User.class, userId);
		System.out.println("deleting");
		System.out.println(user);
			sessionFactory.getCurrentSession().delete(user);
	}

	@Override
	public User searchUser(Integer userId) {
		User user=(User) sessionFactory.getCurrentSession().get(User.class, userId);
		return user;
	}

	@Override
	public void savePassword(User user, String current) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Object> getUserBookingHistory(Integer userId) {
		//String sql= "select x.event_name,y.create_date,y.delete_date from (select event_name from event where event_id in(select event_id from booking where user_id='"+userId+"'))as x,(select create_date,delete_date from booking where user_id='"+userId+"')as y";
		
		String event="select event_name from event where event_id in(select event_id from booking where user_id='"+userId+"')";
		List<Object> e= sessionFactory.getCurrentSession().createSQLQuery(event).list();
		String booking="select create_date from booking where user_id='"+userId+"'";
		List<Object> b= sessionFactory.getCurrentSession().createSQLQuery(booking).list();
		e.add(b);
		
		return e;
		
	}

	@Override
	public List<Object> userEvents(Integer userId) {
		
return sessionFactory.getCurrentSession().createSQLQuery("select event_name,event_date from event where event_date > SYSDATE()").list();

			
		
		
	}

	
	
	
	
	}
	

