package com.bme.dao;

import java.util.List;


import com.bme.pojo.User;

public interface UserDao {

	public void saveUser(User user);

	
	public List<User> getAllUsers();
	
	public void deleteUser(Integer userId);

	
	public User searchUser(Integer userId);


	


	public void savePassword(User user, String current);


	public List<Object> getUserBookingHistory(Integer userId);


	public List<Object> userEvents(Integer userId);


	
	
	
}
