package org.capgemini.test.dao;

import static org.junit.Assert.*;


import java.util.ArrayList;

import org.junit.Test;

import com.bme.dao.UserDao;
import com.bme.dao.UserDaoImpl;
import com.bme.pojo.User;

public class DaoTesting {
	
	private UserDao userDao=new UserDaoImpl();

	@Test
	public void test() {
		
		assertTrue(true);
		
	}

}
