package com.bme.dao;

import java.util.List;

import com.bme.pojo.Booking;



public interface BookingDao {
	
	public boolean bookEvent(Booking event);
	
	public boolean cancelBooking(int bookingId,int userId);
	public List<Booking> getAllAccounts();


}
