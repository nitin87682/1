package com.bme.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bme.pojo.Booking;

@Repository
public class BookingDaoImp implements BookingDao{

	@Autowired
	private SessionFactory sessionFactory;

	
	//Method to save Booking
	
	@Transactional
	public boolean bookEvent(Booking event) {


		if(event.getTicketType().equals("Gold"))
		{
			int goldCap=(int) sessionFactory.getCurrentSession().createQuery("select currentGoldCapacity from Capacity where capacityId="+event.getEventId()).uniqueResult();
			if(goldCap>event.getNoOfTickets())
			{
				if(event.getTransactionId()>0)
				{
					sessionFactory.getCurrentSession().save(event);

					sessionFactory.getCurrentSession().createQuery("update Capacity set currentGoldCapacity ="+(goldCap-event.getNoOfTickets())+"where capacityId="+event.getEventId()).executeUpdate();
					return true;
				}
				return false;
			}

		}

		else if(event.getTicketType().equals("Silver"))
		{
			int silverCap=(int) sessionFactory.getCurrentSession().createQuery("select currentSilverCapacity from Capacity where capacityId="+event.getEventId()).uniqueResult();
			if(silverCap>event.getNoOfTickets())
			{
				if(event.getTransactionId()>0)
				{
					sessionFactory.getCurrentSession().save(event);
					int bookingId=(int)sessionFactory.getCurrentSession().createQuery("select bookingId from Booking where userId="+event.getUserId()+" and eventId="+event.getEventId()+" and amountPaid="+event.getAmountPaid()).uniqueResult();
					event.setBookingId(bookingId);
					sessionFactory.getCurrentSession().createQuery("update Capacity set currentSilverCapacity ="+(silverCap-event.getNoOfTickets())+"where capacityId="+event.getEventId()).executeUpdate();
					return true;
				}
				return false;
			}
		}
		else if(event.getTicketType().equals("Platinum"))
		{
			int platinumCap=(int) sessionFactory.getCurrentSession().createQuery("select currentPlatinumCapacity from Capacity where capacityId="+event.getEventId()).uniqueResult();
			if(platinumCap>event.getNoOfTickets())
			{
				if(event.getTransactionId()>0)
				{
					sessionFactory.getCurrentSession().save(event);
					int bookingId=(int)sessionFactory.getCurrentSession().createQuery("select bookingId from Booking where userId="+event.getUserId()+" and eventId="+event.getEventId()+" and amountPaid="+event.getAmountPaid()).uniqueResult();
					event.setBookingId(bookingId);
					sessionFactory.getCurrentSession().createQuery("update Capacity set currentPlatinumCapacity ="+(platinumCap-event.getNoOfTickets())+"where capacityId="+event.getEventId()).executeUpdate();
					return true;
				}
				return false;
			}
		}


		return false;
	}

	
	
	//Method to show all Bookings 
	
	@Transactional
	public List<Booking> getAllAccounts() {

		return sessionFactory.getCurrentSession().createQuery("from Booking").list();
	}

	
	//Method to cancel booking
	
	@Transactional
	public boolean cancelBooking(int bookingId,int userId) 
	
	{
		String ticketType=(String)sessionFactory.getCurrentSession().createQuery("select ticketType from Booking where bookingId="+bookingId).uniqueResult();
		int eventId=(Integer) sessionFactory.getCurrentSession().createQuery("select eventId from Booking where bookingId="+bookingId).uniqueResult(); 
		int noOfTickets=(Integer) sessionFactory.getCurrentSession().createQuery("select noOfTickets from Booking where bookingId="+bookingId).uniqueResult();

		
		if(ticketType.equals("Gold"))
		{
			int goldCap=(int) sessionFactory.getCurrentSession().createQuery("select currentGoldCapacity from Capacity where capacityId="+eventId).uniqueResult();
			
			sessionFactory.getCurrentSession().createQuery("update Capacity set currentGoldCapacity ="+(goldCap+noOfTickets)+"where capacityId="+eventId).executeUpdate();

		}
		else if(ticketType.equals("Silver"))
		{
			int silverCap=(int) sessionFactory.getCurrentSession().createQuery("select currentSilverCapacity from Capacity where capacityId="+eventId).uniqueResult();
		
			sessionFactory.getCurrentSession().createQuery("update Capacity set currentSilverCapacity ="+(silverCap+noOfTickets)+"where capacityId="+eventId).executeUpdate();
		}

		else if(ticketType.equals("Platinum"))
		{
			int platinumCap=(int) sessionFactory.getCurrentSession().createQuery("select currentPlatinumCapacity from Capacity where capacityId="+eventId).uniqueResult();
		
			sessionFactory.getCurrentSession().createQuery("update Capacity set currentPlatinumCapacity ="+(platinumCap+noOfTickets)+"where capacityId="+eventId).executeUpdate();
		}
		int result=sessionFactory.getCurrentSession().createQuery("delete from Booking where bookingId="+bookingId+" and userId="+userId).executeUpdate();
		if(result>0)
		{
			return true;
		}
		return false;
	}

}
