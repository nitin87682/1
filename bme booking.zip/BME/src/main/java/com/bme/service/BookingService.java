package com.bme.service;

import java.util.List;

import com.bme.pojo.Booking;



public interface BookingService {
	public Booking bookEvent(Booking event);
	
	public String cancelBooking(int bookingId,int userId);
	public List<Booking> getAllAccounts() ;
/*	public void deleteAcount(Integer eventId);
*/	//public Event searchEvent(Integer eventId);
}
