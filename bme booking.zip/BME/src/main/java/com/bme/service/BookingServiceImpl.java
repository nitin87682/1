package com.bme.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bme.dao.BookingDao;
import com.bme.pojo.Booking;

@Service
public class BookingServiceImpl implements BookingService{

	@Autowired
	private BookingDao bookingDao;

	
	
	@Transactional
	public Booking bookEvent(Booking event) {

		//calling repo method for saving booking
		
		if( bookingDao.bookEvent(event))
		{
			return event;
		}
		return null;

	}

	@Transactional
	public List<Booking> getAllAccounts() {
		//calling repo method to show all bookings
		
		return bookingDao.getAllAccounts();
	}

	@Transactional
	public String cancelBooking(int bookingId,int userId)
	{
		//Calling repo method to cancel booking
		
		if(bookingDao.cancelBooking(bookingId,userId))
		{
			return "Booking Cancelled";

		}
		return "booking was not cancelled";
	}
}
