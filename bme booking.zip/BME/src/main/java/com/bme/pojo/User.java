package com.bme.pojo;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="USER_Info")
public class User implements Serializable
{

private static final long serialVersionUID = 1L;
@Id
/*@OneToOne(targetEntity=Booking.class)
*/@Column(name="user_id")
private String userId;

@Column(name="first_name")
private String firstName;

@Column(name="last_name")
private String lastName;

@Column(name="date_of_birth")
private Date date_of_birth;

@Column(name="email_id")
private String email;

@Column(name="password")
private String password;

@Column(name="contact_number")
private int contact_no;

@Column(name="image_url")
private String image;

@Column(name="address")
private String address;

@Column(name="role")
private String role;

@Column(name="create_date")
private Date create_date;

@Column(name="delete_date")
private Date delete_date;

@Column(name="security_question")
private String security_qustn;

@Column(name="security_answer")
private String security_answer;

@Column(name="activation_status")
private Boolean activationstatus;


public User(){}
public User(String userId, String firstName, String lastName,
		Date date_of_birth, String email, String password, int contact_no,
		String image, String address, String role, Date create_date,
		Date delete_date, String security_qustn, String security_answer,
		Boolean activationstatus) {
	super();
	this.userId = userId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.date_of_birth = date_of_birth;
	this.email = email;
	this.password = password;
	this.contact_no = contact_no;
	this.image = image;
	this.address = address;
	this.role = role;
	this.create_date = create_date;
	this.delete_date = delete_date;
	this.security_qustn = security_qustn;
	this.security_answer = security_answer;
	this.activationstatus = activationstatus;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public Date getDate_of_birth() {
	return date_of_birth;
}
public void setDate_of_birth(Date date_of_birth) {
	this.date_of_birth = date_of_birth;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getContact_no() {
	return contact_no;
}
public void setContact_no(int contact_no) {
	this.contact_no = contact_no;
}
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public Date getCreate_date() {
	return create_date;
}
public void setCreate_date(Date create_date) {
	this.create_date = create_date;
}
public Date getDelete_date() {
	return delete_date;
}
public void setDelete_date(Date delete_date) {
	this.delete_date = delete_date;
}
public String getSecurity_qustn() {
	return security_qustn;
}
public void setSecurity_qustn(String security_qustn) {
	this.security_qustn = security_qustn;
}
public String getSecurity_answer() {
	return security_answer;
}
public void setSecurity_answer(String security_answer) {
	this.security_answer = security_answer;
}
public Boolean getActivationstatus() {
	return activationstatus;
}
public void setActivationstatus(Boolean activationstatus) {
	this.activationstatus = activationstatus;
}
public static long getSerialversionuid() {
	return serialVersionUID;
}
@Override
public String toString() {
	return "User [userId=" + userId + ", firstName=" + firstName
			+ ", lastName=" + lastName + ", date_of_birth=" + date_of_birth
			+ ", email=" + email + ", password=" + password + ", contact_no="
			+ contact_no + ", image=" + image + ", address=" + address
			+ ", role=" + role + ", create_date=" + create_date
			+ ", delete_date=" + delete_date + ", security_qustn="
			+ security_qustn + ", security_answer=" + security_answer
			+ ", activationstatus=" + activationstatus + "]";
}




} 