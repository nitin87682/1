package com.bme.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Organiser {
	@Id
	@GeneratedValue
	@OneToOne(targetEntity=Event.class)
	@Column(name="organiser_id")
private int organiserId;
	
	@Column(name="organiser_name")
private String oraganiserName;

public int getOrganiserId() {
	return organiserId;
}
public void setOrganiserId(int organiserId) {
	this.organiserId = organiserId;
}
public String getOraganiserName() {
	return oraganiserName;
}
public void setOraganiserName(String oraganiserName) {
	this.oraganiserName = oraganiserName;
}

public Organiser(int organiserId, String oraganiserName) {
	super();
	this.organiserId = organiserId;
	this.oraganiserName = oraganiserName;
	
}


public Organiser() {}
@Override
public String toString() {
	return "Organiser [organiserId=" + organiserId + ", oraganiserName="
			+ oraganiserName + "]";
}




}