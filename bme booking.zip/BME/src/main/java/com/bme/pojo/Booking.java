package com.bme.pojo;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

//Booking pojo


@Entity
@Table(name="booking")
public class Booking {

	@Id
	@GeneratedValue
	@Column(name="booking_id")
	private int bookingId;
	@Column(name="user_id")
	private int userId;
	@Column(name="event_id")
	private int eventId;
	@Column(name="no_of_tickets")
	private int noOfTickets;
	@Column(name="transaction_id")
	private int transactionId;
	
	@Column(name="amount_paid")
	private double amountPaid;
	
	@Column(name="ticket_type")
	private String ticketType;
	@Column(name="create_date")
	private Date createDate;
	@Column(name="delete_date")
	private Date deleteDate;
	
	public Booking(){}

	public Booking(int bookingId, int userId, int eventId, int noOfTickets,
			int transactionId, double amountPaid, String ticketType,
			Date createDate, Date deleteDate) {
		super();
		this.bookingId = bookingId;
		this.userId = userId;
		this.eventId = eventId;
		this.noOfTickets = noOfTickets;
		this.transactionId = transactionId;
		this.amountPaid = amountPaid;
		this.ticketType = ticketType;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public int getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public String getTicketType() {
		return ticketType;
	}

	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", userId=" + userId
				+ ", eventId=" + eventId + ", noOfTickets=" + noOfTickets
				+ ", transactionId=" + transactionId + ", amountPaid="
				+ amountPaid + ", ticketType=" + ticketType + ", createDate="
				+ createDate + ", deleteDate=" + deleteDate + "]";
	}

	
}
