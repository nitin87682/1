package com.bme.pojo;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Venue {


	@Id
	@GeneratedValue
	@OneToOne(targetEntity=Event.class)
	@Column(name="venue_id")
	private int venueId;
	
	@Column(name="venue_name")
	private String venueName;
	
	@Column(name="venue_city")
	private String venueCity;
	
	@Column(name="create_date")
	private Date createDate;
	
	@Column(name="delete_date")
	private Date deleteDate;
	public int getVenueId() {
		return venueId;
	}
	public void setVenueId(int venueId) {
		this.venueId = venueId;
	}
	public String getVenueName() {
		return venueName;
	}
	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}
	public String getVenueCity() {
		return venueCity;
	}
	public void setVenueCity(String venueCity) {
		this.venueCity = venueCity;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	@Override
	public String toString() {
		return "Venue [venueId=" + venueId + ", venueName=" + venueName
				+ ", venueCity=" + venueCity + ", createDate=" + createDate
				+ ", deleteDate=" + deleteDate + "]";
	}
	public Venue(int venueId, String venueName, String venueCity,
			Date createDate, Date deleteDate) {
		super();
		this.venueId = venueId;
		this.venueName = venueName;
		this.venueCity = venueCity;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}
	public Venue() {}

}
