package com.bme.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Capacity {

	@Id
	@GeneratedValue
	@OneToOne(targetEntity=Event.class)
	@Column(name="capacity_id")
	private int capacityId;
	@Column(name="silver_capacity")
	private int silverCapacity;
	
	@Column(name="gold_capacity")
	private int goldCapacity;
	
	@Column(name="platinum_capacity")
	private int platinumCapacity;
	
	@Column(name="silver_current_capacity")
	private int currentSilverCapacity;
	
	@Column(name="gold_current_capacity")
	private int currentGoldCapacity;
	
	@Column(name="platinum_current_capacity")
	private int currentPlatinumCapacity;
	public int getCapacityId() {
		return capacityId;
	}
	public void setCapacityId(int capacityId) {
		this.capacityId = capacityId;
	}
	public int getSilverCapacity() {
		return silverCapacity;
	}
	public void setSilverCapacity(int silverCapacity) {
		this.silverCapacity = silverCapacity;
	}
	public int getGoldCapacity() {
		return goldCapacity;
	}
	public void setGoldCapacity(int goldCapacity) {
		this.goldCapacity = goldCapacity;
	}
	public int getPlatinumCapacity() {
		return platinumCapacity;
	}
	public void setPlatinumCapacity(int platinumCapacity) {
		this.platinumCapacity = platinumCapacity;
	}
	public int getCurrentSilverCapacity() {
		return currentSilverCapacity;
	}
	public void setCurrentSilverCapacity(int currentSilverCapacity) {
		this.currentSilverCapacity = currentSilverCapacity;
	}
	public int getCurrentGoldCapacity() {
		return currentGoldCapacity;
	}
	public void setCurrentGoldCapacity(int currentGoldCapacity) {
		this.currentGoldCapacity = currentGoldCapacity;
	}
	public int getCurrentPlatinumCapacity() {
		return currentPlatinumCapacity;
	}
	public void setCurrentPlatinumCapacity(int currentPlatinumCapacity) {
		this.currentPlatinumCapacity = currentPlatinumCapacity;
	}
	@Override
	public String toString() {
		return "Capacity [capacityId=" + capacityId + ", silverCapacity="
				+ silverCapacity + ", goldCapacity=" + goldCapacity
				+ ", platinumCapacity=" + platinumCapacity
				+ ", currentSilverCapacity=" + currentSilverCapacity
				+ ", currentGoldCapacity=" + currentGoldCapacity
				+ ", currentPlatinumCapacity=" + currentPlatinumCapacity + "]";
	}
	public Capacity(int capacityId, int silverCapacity, int goldCapacity,
			int platinumCapacity, int currentSilverCapacity,
			int currentGoldCapacity, int currentPlatinumCapacity) {
		super();
		this.capacityId = capacityId;
		this.silverCapacity = silverCapacity;
		this.goldCapacity = goldCapacity;
		this.platinumCapacity = platinumCapacity;
		this.currentSilverCapacity = currentSilverCapacity;
		this.currentGoldCapacity = currentGoldCapacity;
		this.currentPlatinumCapacity = currentPlatinumCapacity;
	}

	public Capacity() {}
	
}
