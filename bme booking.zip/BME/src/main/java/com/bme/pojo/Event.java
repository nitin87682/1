package com.bme.pojo;

import java.sql.Time;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="event")

public class Event {

	@Id
	@Column(name="event_id")
	@GeneratedValue
/*	@OneToOne(targetEntity=Booking.class)
*/	private int eventId;
	
	@Column(name="event_name")
	private String eventName;
	
	@Column(name="event_date")
	private Date eventDate;
	
	@Column(name="event_certificate")
	private String eventCertificate;
	
	@Column(name="event_description")
	private String description;

	@Column(name="event_status")
	private String eventStatus;
	
	@Column(name="event_time")
	private Time eventTime;
	
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="organiseId")
	@Column(name="organiser_id")
	private Organiser organiser;
	@Column(name="capacity2")
	private int capacity2;
	
/*	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="capacityId")
	@Column(name="capacity_id")
	private Capacity capacity;
	
	*/
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="priceId")
	@Column(name="price_id")
	private Price price;
	
	
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="venueId")
	@Column(name="venue_id")
	private Venue venue;
	
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="performerId")
	@Column(name="performer_id")
	private Performer performer;
	
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="categoryId")
	@Column(name="category_id")
	private Category category;
	
	@Column(name="create_date")
	private Date createDate;
	@Column(name="delete_date")
	private Date deleteDate;
	/*public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventCertificate() {
		return eventCertificate;
	}
	public void setEventCertificate(String eventCertificate) {
		this.eventCertificate = eventCertificate;
	}
	public Organiser getOrganiser() {
		return organiser;
	}
	public void setOrganiser(Organiser organiser) {
		this.organiser = organiser;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public Time getEventTime() {
		return eventTime;
	}
	public void setEventTime(Time eventTime) {
		this.eventTime = eventTime;
	}
	public Capacity getCapacity() {
		return capacity;
	}
	public void setCapacity(Capacity capacity) {
		this.capacity = capacity;
	}
	public Price getPrice() {
		return price;
	}
	public void setPrice(Price price) {
		this.price = price;
	}
	public Venue getVenue() {
		return venue;
	}
	public void setVenue(Venue venue) {
		this.venue = venue;
	}
	public Performer getPerformer() {
		return performer;
	}
	public void setPerformer(Performer performer) {
		this.performer = performer;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Event(int eventId, String eventName, Date eventDate,
			String eventCertificate, Organiser organiser, String description,
			String eventStatus, Time eventTime, Capacity capacity, Price price,
			Venue venue, Performer performer, Category category,
			Date createDate, Date deleteDate) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.eventDate = eventDate;
		this.eventCertificate = eventCertificate;
		this.organiser = organiser;
		this.description = description;
		this.eventStatus = eventStatus;
		this.eventTime = eventTime;
		this.capacity = capacity;
		this.price = price;
		this.venue = venue;
		this.performer = performer;
		this.category = category;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}

	public Event() {}
	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eventName=" + eventName
				+ ", eventDate=" + eventDate + ", eventCertificate="
				+ eventCertificate + ", organiser=" + organiser
				+ ", description=" + description + ", eventStatus="
				+ eventStatus + ", eventTime=" + eventTime + ", capacity="
				+ capacity + ", price=" + price + ", venue=" + venue
				+ ", performer=" + performer + ", category=" + category
				+ ", createDate=" + createDate + ", deleteDate=" + deleteDate
				+ "]";
	}

*/
	
	public Event(){}
	public Event(int eventId, String eventName, Date eventDate,
			String eventCertificate, String description, String eventStatus,
			Time eventTime, Organiser organiser, int capacityId, Price price,
			Venue venue, Performer performer, Category category,
			Date createDate, Date deleteDate) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.eventDate = eventDate;
		this.eventCertificate = eventCertificate;
		this.description = description;
		this.eventStatus = eventStatus;
		this.eventTime = eventTime;
		this.organiser = organiser;
		this.capacity2 = capacityId;
		this.price = price;
		this.venue = venue;
		this.performer = performer;
		this.category = category;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventCertificate() {
		return eventCertificate;
	}
	public void setEventCertificate(String eventCertificate) {
		this.eventCertificate = eventCertificate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public Time getEventTime() {
		return eventTime;
	}
	public void setEventTime(Time eventTime) {
		this.eventTime = eventTime;
	}
	public Organiser getOrganiser() {
		return organiser;
	}
	public void setOrganiser(Organiser organiser) {
		this.organiser = organiser;
	}
	public int getCapacityId() {
		return capacity2;
	}
	public void setCapacityId(int capacityId) {
		this.capacity2 = capacityId;
	}
	public Price getPrice() {
		return price;
	}
	public void setPrice(Price price) {
		this.price = price;
	}
	public Venue getVenue() {
		return venue;
	}
	public void setVenue(Venue venue) {
		this.venue = venue;
	}
	public Performer getPerformer() {
		return performer;
	}
	public void setPerformer(Performer performer) {
		this.performer = performer;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eventName=" + eventName
				+ ", eventDate=" + eventDate + ", eventCertificate="
				+ eventCertificate + ", description=" + description
				+ ", eventStatus=" + eventStatus + ", eventTime=" + eventTime
				+ ", organiser=" + organiser + ", capacityId=" + capacity2
				+ ", price=" + price + ", venue=" + venue + ", performer="
				+ performer + ", category=" + category + ", createDate="
				+ createDate + ", deleteDate=" + deleteDate + "]";
	}

}



