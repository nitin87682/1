package com.bme.controller;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bme.pojo.Booking;
import com.bme.service.BookingService;

@Controller
public class BookingContoller {

	@Autowired
	private BookingService bookingService;
	private Booking searchBooking=null;
	
	
	//Link from index page
	
	
	@RequestMapping("/booking")
	public String showBookingPage(Map<String, Object> map){
	
		map.put("bookingSearch",searchBooking);
		map.put("booking",new Booking());

	
		return "BookingRegister";
	}




	//Link on clicking save button
	//Controller to save booking in the database table

	@RequestMapping(value={"/saveBooking"},method=RequestMethod.POST,produces = "application/json")
	public @ResponseBody List<Booking> bookEvent(Map<String, Object> map,ModelMap mapping,@RequestParam(value="userId") int userId ,
			@RequestParam(value="eventId") int eventId ,@RequestParam(value="noOfTickets") int noOfTickets,
			@RequestParam(value="amountPaid") double amountPaid, @RequestParam(value="ticketType") String ticketType, 
			@Valid @ModelAttribute("book") Booking book, BindingResult result){
	
		map.put("bookingSearch",searchBooking);
	
		searchBooking=null;
		
		//Adding from the URL
		Booking book12=new Booking();
		book12.setUserId(userId);
		book12.setEventId(eventId);
		book12.setNoOfTickets(noOfTickets);
		book12.setAmountPaid(amountPaid);
		book12.setTicketType(ticketType);
		book12.setCreateDate(new Date());
		book12.setTransactionId(1);

		Booking finalBooking=bookingService.bookEvent(book12);
		List<Booking> list=new ArrayList<Booking>();
		list.add(finalBooking);
		System.out.println(list);
	

		return list;
	}
	
	
	//Link on clicking cancel button
	//Controller for cancelling the booking

	@RequestMapping(value={"/cancelBooking"},method=RequestMethod.POST)
	public String cancelBooking(Map<String, Object> map,ModelMap mapping,
			@RequestParam(value="bookingId") int bookingId,@RequestParam(value="userId") int userId ,
			@Valid @ModelAttribute("book2") Booking book2){

		mapping.addAttribute(new Booking());
		String s=bookingService.cancelBooking(bookingId,userId); 

		System.out.println(s);
		return "BookingRegister";




	}
}
