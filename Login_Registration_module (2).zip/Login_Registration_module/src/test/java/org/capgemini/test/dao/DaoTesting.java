package org.capgemini.test.dao;

import static org.junit.Assert.*;


import java.util.ArrayList;

import org.capgemini.dao.UserDao;
import org.capgemini.dao.UserDaoImpl;
import org.capgemini.pojo.User;
import org.junit.Test;

public class DaoTesting {
	
	private UserDao userDao=new UserDaoImpl();

	@Test
	public void test() {
		
		assertTrue(true);
		
	}

}
