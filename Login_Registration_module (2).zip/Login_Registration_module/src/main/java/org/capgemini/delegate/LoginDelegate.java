package org.capgemini.delegate;

import java.sql.SQLException;

import org.capgemini.service.*;

public class LoginDelegate
{
		private UserService userService;

		public UserService getUserService()
		{
				return this.userService;
		}

		public void setUserService(UserService userService)
		{
				this.userService = userService;
		}

		public boolean isValidUser(String firstname, String password) throws SQLException
    {
		    return userService.isValidUser(firstname, password);
    }
		
		
		
		public boolean SearchByEmail(String email) throws SQLException
	    {
			    return userService.SearchByEmail(email);
	    }

		public boolean resetPassword(String firstname,String security_answer) throws SQLException
	    {
			    return userService.resetPassword(firstname,security_answer);
	    }
}
