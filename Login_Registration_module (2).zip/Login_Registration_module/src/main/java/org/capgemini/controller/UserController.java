package org.capgemini.controller;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.capgemini.delegate.LoginDelegate;
import org.capgemini.pojo.User;
import org.capgemini.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	private User searchuser=null;
	
	@Autowired
	private LoginDelegate loginDelegate;

	@RequestMapping("/userForm")
	public String showUserForm(Map<String, Object> maps){
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		List<User> users=userService.getAllUsers();
		maps.put("users",users);
		maps.put("userSearch",searchuser);
		maps.put("user",new User());
		
		if(searchuser!=null){
		maps.put("user", searchuser);
		Date userDob=searchuser.getDate_of_birth();
	
			if(userDob!=null)
			{		
					String dob=myFormat.format(userDob);
					maps.put("userdob", dob);
			}
			
		}
		 return "user";
	}
	
	
	@RequestMapping(value={"/showUser","/updateUser"},method=RequestMethod.POST)
	public String showEmpDetails(Map<String, Object> map,
			@Valid @ModelAttribute("user") User user, BindingResult result){
		List<User> users=userService.getAllUsers();
		map.put("users",users);
		map.put("userSearch",searchuser);
		if(result.hasErrors()){
			//System.out.println("Search Object:" + searchUser);
			//System.out.println(result);
			return "user";
		}
		else{
			searchuser=null;
			userService.saveUser(user);
			return "redirect:/userForm";
		}
	}
	
	
	
	@RequestMapping("/deleteUser/{userId}")
	public String deleteUser(@PathVariable("userId") Integer userId){
		userService.deleteUser(userId);
		return "redirect:/userForm";
	}
	
	@RequestMapping("/updateUser/{userId}")
	public String  updateUser(@PathVariable("userId") Integer userId){
		User user=userService.searchUser(userId);
		searchuser=user;
		
		return"redirect:/userForm";
	}
	
	
	
	
	
	
	
	

	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView displayLogin(HttpServletRequest request, HttpServletResponse response, User User)
	{
		ModelAndView model = new ModelAndView("login");
		//User User = new User();
		model.addObject("User", User);
		return model;
	}
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public ModelAndView executeLogin(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("User")User User)
	{
			ModelAndView model= null;
			try
			{
					boolean isValidUser = loginDelegate.isValidUser(User.getFirstName(), User.getPassword());
					if(isValidUser)
					{
 							System.out.println("User Login Successful");
							request.setAttribute("loggedInUser", User.getFirstName());
							model = new ModelAndView("welcome");
							//return new ModelAndView("redirect:/welcome");
					}
					else
					{
							model = new ModelAndView("login");
							request.setAttribute("message", "Invalid credentials!!");
					}

			}
			catch(Exception e)
			{
					e.printStackTrace();
			}

			return model;
	}

	@RequestMapping(value="/userForm",method=RequestMethod.POST)
	public ModelAndView executeDuplicateLogin(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("User")User User)
	{
			ModelAndView model= null;
			try
			{
					boolean SearchByEmail = loginDelegate.SearchByEmail(User.getEmail());
					if(SearchByEmail)
					{
							System.out.println("You are already Logged in.");
							request.setAttribute("message", "You are already logged in.");
							model = new ModelAndView("login");
							//return new ModelAndView("redirect:/welcome");
					}
					

			}
			catch(Exception e)
			{
					e.printStackTrace();
			}

			return model;
	}


	@RequestMapping(value="/reset",method=RequestMethod.GET)
	public ModelAndView displayreset(HttpServletRequest request, HttpServletResponse response, User User)
	{
		ModelAndView model = new ModelAndView("reset");
		//User User = new User();
		model.addObject("User", User);
		return model;
	}
	
	@RequestMapping(value="/reset",method=RequestMethod.POST)
	public ModelAndView resetPassword(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("User")User User)
	{
			ModelAndView model= null;
			try
			{
					boolean resetPassword = loginDelegate.resetPassword(User.getFirstName(),User.getSecurity_answer());
					if(resetPassword)
					{
							System.out.println("set ur password");
							request.setAttribute("loggedInUser", User.getFirstName());
							request.setAttribute("message", "reset ur password");
							model = new ModelAndView("login");
							//return new ModelAndView("redirect:/welcome");
					}

			}
			catch(Exception e)
			{
					e.printStackTrace();
			}

			return model;
	}
	
	
}