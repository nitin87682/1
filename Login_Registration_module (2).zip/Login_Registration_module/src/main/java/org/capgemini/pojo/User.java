package org.capgemini.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_info")
public class User {
	
	@Id
	@GeneratedValue
	@Column(name="user_id")
	private int userId;
	@Column(name="first_name")
	private String firstName;
	@Column(name="last_name")
	private String lastName;
	@Column(name="date_of_birth")
	private Date date_of_birth;
	@Column(name="email_id")
	private String email;
	@Column(name="password")
	private String password;
	@Column(name="contact_number")
	private int contact_no;
	@Column(name="image_url")
	private String image;
	@Column(name="address")
	private String address;
	@Column(name="role")
	private String role;
	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}



	public Date getDeleteDate() {
		return deleteDate;
	}



	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}



	public Date getCreateDate() {
		return createDate;
	}



	@Column(name="security_question")
	private String security_qustn;
	@Column(name="security_answer")
	private String security_answer;
	@Column(name="create_date")
	private Date createDate;
	@Column(name="delete_date")
	private Date deleteDate;
	
	public String getType_of_user() {
		return role;
	}



	public void setType_of_user(String role) {
		this.role = role;
	}



	
	
	public User() {
		super();
	}



	public User(int userId, String lastName, Date date_of_birth, String email, String password, int contact_no,
			String image, String address,String role, Date create_date, Date delete_date, String security_qustn,
			String security_answer, String firstName) {
		super();
		this.userId = userId;
		this.lastName = lastName;
		this.date_of_birth = date_of_birth;
		this.email = email;
		this.password = password;
		this.contact_no = contact_no;
		this.image = image;
		this.address = address;
		this.role=role;
	
		this.security_qustn = security_qustn;
		this.security_answer = security_answer;
		
		this.firstName = firstName;
	}



	public int getUserId() {
		return userId;
	}



	public void setUserId(int userId) {
		this.userId = userId;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public Date getDate_of_birth() {
		return date_of_birth;
	}



	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public int getContact_no() {
		return contact_no;
	}



	public void setContact_no(int contact_no) {
		this.contact_no = contact_no;
	}



	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	



	public String getSecurity_qustn() {
		return security_qustn;
	}



	public void setSecurity_qustn(String security_qustn) {
		this.security_qustn = security_qustn;
	}



	public String getSecurity_answer() {
		return security_answer;
	}



	public void setSecurity_answer(String security_answer) {
		this.security_answer = security_answer;
	}






	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	@Override
	public String toString() {
		return "UserLogin [userId=" + userId + ", lastName=" + lastName + ", date_of_birth=" + date_of_birth + ", email="
				+ email + ", password=" + password + ", contact_no=" + contact_no + ", image=" + image + ", address="
				+ address + ", create_date="  + ", delete_date=" + ", security_qustn="
				+ security_qustn + ", security_answer=" + security_answer + ", activationstatus=" + 
				 ", firstName=" + firstName + "]";
	}



	public void setCreateDate(Date createDate) {
		// TODO Auto-generated method stub
		this.createDate = createDate;
		
	}
}

	
	
	