package org.capgemini.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="log_info")
public class Logs {
	
	@Id
	@GeneratedValue
	@Column(name="log_id")
	private int log_id;
	
	@Column(name="user_id")
	private int user_id;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="role")
	private String role;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="log_time")
	private Date logTime;
	
	@Column(name="log_method")
	private String logMethod;
	
	public Logs(){}
	

	public Logs(int log_id, int user_id, String firstName, String lastName,
			String role, Date logTime, String logMethod) {
		super();
		this.log_id = log_id;
		this.user_id = user_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.role = role;
		this.logTime = logTime;
		this.logMethod = logMethod;
	}
	

	public int getLog_id() {
		return log_id;
	}

	public void setLog_id(int log_id) {
		this.log_id = log_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Date getLogTime() {
		return logTime;
	}

	public void setLogTime(Date logTime) {
		this.logTime = logTime;
	}

	public String getLogMethod() {
		return logMethod;
	}

	public void setLogMethod(String logMethod) {
		this.logMethod = logMethod;
	}

	@Override
	public String toString() {
		return "Logs [log_id=" + log_id + ", user_id=" + user_id
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", role=" + role + ", logTime=" + logTime + ", logDetails="
				+ logMethod + "]";
	}
	
	
	
	
	

}
