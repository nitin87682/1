package org.capgemini.dao;

import java.sql.SQLException;

import org.aspectj.lang.JoinPoint;
import org.capgemini.pojo.User;

public interface LogDao {
	
	public void logBeforeRegistrationDao(JoinPoint joinPoint);
	public void logAfterRegistrationDao(JoinPoint joinPoint,User user);
	
	public void logBeforeLoginDao(JoinPoint joinPoint,String firstName,String password) throws SQLException;
	public void logAfterLoginDao(JoinPoint joinPoint,String firstName,String password) throws SQLException, ClassNotFoundException;

}
