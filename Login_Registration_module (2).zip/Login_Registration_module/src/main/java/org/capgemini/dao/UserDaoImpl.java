package org.capgemini.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.capgemini.pojo.User;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements UserDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveUser(User user) {

		user.setCreateDate(new Date());
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}

	public List<User> getAllUsers() {
		
		return sessionFactory.getCurrentSession().createQuery("from User").list();
	}

	public void deleteUser(Integer userId) {
		User user=(User) sessionFactory.getCurrentSession().get(User.class, userId);
		if(user!=null)
			sessionFactory.getCurrentSession().delete(user);
	}

	public User searchUser(Integer userId) {
		User user=(User) sessionFactory.getCurrentSession().get(User.class, userId);
		return user;
	}

	
	
	
	

	
	DataSource dataSource;

	public DataSource getDataSource()
	{
			return this.dataSource;
	}

	public void setDataSource(DataSource dataSource)
	{
			this.dataSource = dataSource;
	}

	@Override
	public boolean isValidUser(String firstname, String password) throws SQLException
	{
			String query = "Select count(1) from user_info where first_name = ? and password = ?";
			PreparedStatement pstmt = dataSource.getConnection().prepareStatement(query);
			pstmt.setString(1, firstname);
			pstmt.setString(2, password);
			ResultSet resultSet = pstmt.executeQuery();
			if (resultSet.next())
					return (resultSet.getInt(1) > 0);
			else
					return false;
	}
	
	
	
	@Override
	public boolean SearchByEmail(String email) throws SQLException
	{
			String query = "Select count(1) from user_info where email_id=?";
			PreparedStatement pstmt = dataSource.getConnection().prepareStatement(query);
			pstmt.setString(1, email);
			
			ResultSet resultSet = pstmt.executeQuery();
			if (resultSet.next())
					return (resultSet.getInt(1) > 0);
			else
					return false;
	}

	@Override
	public boolean resetPassword(String firstName,String security_answer) throws SQLException {
		String query = "Select count(1) from user_info where first_name = ? and security_answer=?";
		PreparedStatement pstmt = dataSource.getConnection().prepareStatement(query);
		pstmt.setString(1, firstName);
		pstmt.setString(2, security_answer);
		
		ResultSet resultSet = pstmt.executeQuery();
		if (resultSet.next())
				return (resultSet.getInt(1) > 0);
		else
				return false;
	}
	}
	

