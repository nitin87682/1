package org.capgemini.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.aspectj.lang.JoinPoint;
import org.capgemini.pojo.Logs;
import org.capgemini.pojo.User;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class LogDaoImpl implements LogDao {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void logBeforeRegistrationDao(JoinPoint joinPoint) {

		System.out.println("*****in logs before*****");

	}

	@Override
	public void logAfterRegistrationDao(JoinPoint joinPoint,User user) {

		System.out.println("*****in logs after*****");

		Logs log=new Logs();
		log.setUser_id(user.getUserId());
		log.setFirstName(user.getFirstName());
		log.setLastName(user.getLastName());
		log.setRole(user.getRole());
		log.setLogTime(new Date());
		log.setLogMethod(joinPoint.getSignature().getName());

		sessionFactory.getCurrentSession().saveOrUpdate(log);
		
	}


	

	@Override
	public void logBeforeLoginDao(JoinPoint joinPoint,String firstName,String password) throws SQLException {
		System.out.println("*******in logs before******");

	}


	DataSource dataSource;

	public DataSource getDataSource()
	{
		return this.dataSource;
	}

	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}


	@Override
	public void logAfterLoginDao(JoinPoint joinPoint, String firstName,
			String password) throws SQLException, ClassNotFoundException 
			{
		System.out.println("*****in logs after*****");
		
		
		/*Class.forName("com.mysql.jdbc.Driver");  


		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/test_database","root","preethajra@93");  

		
		String query = "Select * from user_info where first_name = ? and password = ?";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(query);
		pstmt.setString(1, firstName);
		pstmt.setString(2, password);
		ResultSet resultSet = pstmt.executeQuery();
		User user=new User();
		if (resultSet.next())
		{

			user.setUserId(resultSet.getInt("user_id"));
			user.setFirstName(resultSet.getString("first_name"));
			user.setLastName(resultSet.getString("last_name"));
			user.setRole(resultSet.getString("role"));
		}

		

		String query1 = "Insert into log_info(first_name,last_name,log_method,log_time,role,user_id) values(?,?,?,sysdate(),?,?)";
		PreparedStatement pstmt2 = (PreparedStatement) con.prepareStatement(query1);
		pstmt2.setString(1, user.getFirstName());
		pstmt2.setString(2, user.getLastName());
		pstmt2.setString(3, joinPoint.getSignature().getName());
		pstmt2.setString(4, user.getRole());
		pstmt2.setInt(5, user.getUserId());
		
		pstmt2.executeUpdate();*/
		
		
		
		List<User> al=sessionFactory.getCurrentSession().createQuery(" from  User where first_name='"+firstName+"' and password ='"+password+"'").list();
        //al.get(0);

        Logs log=new Logs();
        
        log.setUser_id(al.get(0).getUserId());
        log.setFirstName(al.get(0).getFirstName());
        log.setLastName(al.get(0).getLastName());
        log.setRole(al.get(0).getRole());
        log.setLogTime(new Date());
        log.setLogMethod(joinPoint.getSignature().getName());
        
        sessionFactory.getCurrentSession().saveOrUpdate(log);

		
			}


}


