package org.capgemini.service;

import java.sql.SQLException;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.capgemini.dao.LogDao;
import org.capgemini.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Aspect
public class LogServiceImpl implements LogService {
	
	@Autowired
	private LogDao logDao;

	public LogDao getLogDao() {
		return logDao;
	}

	public void setLogDao(LogDao logDao) {
		this.logDao = logDao;
	}

	@Transactional
	@Before("execution(* org.capgemini.service.UserServiceImpl.saveUser(..))")
	public void logBeforeRegistrationService(JoinPoint joinPoint) {
		
		logDao.logBeforeRegistrationDao(joinPoint);
		
	}

	@Transactional
	@After("execution(* org.capgemini.service.UserServiceImpl.saveUser(..))  && args(user,..)")
	public void logAfterRegistrationService(JoinPoint joinPoint,User user) {
		
		logDao.logAfterRegistrationDao(joinPoint,user);
		
	}

	@Transactional
	@Before("execution(* org.capgemini.service.UserServiceImpl.isValidUser(..))  && args(firstName,password,..)")
	public void logBeforeLoginService(JoinPoint joinPoint,String firstName,String password) throws SQLException {
		logDao.logBeforeLoginDao(joinPoint,firstName,password);
		
	}

	@Transactional
	@After("execution(* org.capgemini.service.UserServiceImpl.isValidUser(..))  && args(firstName,password,..)")
	public void logAfterLoginService(JoinPoint joinPoint, String firstName,String password) throws SQLException, ClassNotFoundException {
		logDao.logAfterLoginDao(joinPoint, firstName, password);
		
	}

}
