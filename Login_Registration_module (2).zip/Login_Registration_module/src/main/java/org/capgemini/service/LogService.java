package org.capgemini.service;

import java.sql.SQLException;

import org.aspectj.lang.JoinPoint;
import org.capgemini.pojo.User;

public interface LogService {
	
	
	
	public void logBeforeRegistrationService(JoinPoint joinPoint);
	public void logAfterRegistrationService(JoinPoint joinPoint,User user);
	public void logBeforeLoginService(JoinPoint joinPoint,String firstName,String password) throws SQLException;
	public void logAfterLoginService(JoinPoint joinPoint,String firstName,String password) throws SQLException, ClassNotFoundException;
	

}
