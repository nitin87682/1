package org.capgemini.service;

import java.sql.SQLException;
import java.util.List;


import org.capgemini.pojo.User;

public interface UserService {
	public void saveUser(User user);
	public List<User> getAllUsers();
	public void deleteUser(Integer userId);
	public User searchUser(Integer UserId);
	
	
	
	public boolean isValidUser(String firstname, String password) throws SQLException;
	
	public boolean SearchByEmail(String email) throws SQLException;
	
	public boolean resetPassword(String firstname,String security_answer) throws SQLException;
}
