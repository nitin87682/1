
package com.bme.controller;


import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;



import com.bme.dao.BankDaoImpl;
import com.bme.pojo.BankAccount;
import com.bme.pojo.BankEventTransaction;
import com.bme.service.IBankService;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BankController {

	@Autowired
	private IBankService bankService;
	@RequestMapping("/bankpage")
	public String showAccountPage(Map<String, Object> map){

		map.put("baccount", new BankAccount());
		map.put("bank", bankService.getAllAccounts());

		return "bankRegister";
	}
	@RequestMapping(value="/saveAccount",method=RequestMethod.POST)
	public String saveAccount(@Valid @ModelAttribute("baccount") BankAccount baccount,
			BindingResult result){


		bankService.saveAccount(baccount);

		return "redirect:/bankpage";
	}


	@RequestMapping("/delete/{accountNo}")
	public String deleteAccount(@PathVariable("accountNo") Integer accNum){
		bankService.deleteAccount(accNum);
		return "redirect:/bankpage";
	}


	@RequestMapping("/BankLogin")
	public String BankLogin(){
		return "BankLogin";

	}

	@RequestMapping("/BankWelcome")
	public String BankWelcome(){
		return "BankWelcome";


	}

	@RequestMapping("/cancelBooking")
	public String cancelBooking(){
		return "cancelBooking";


	}
	@RequestMapping("/TransactionMsg")
	public String TransactionMsg(){
		return "TransactionMsg";
	}

	@RequestMapping("/TransactionSuccess")
	public String TransactionSuccess(){
		return "TransactionSuccess";


	}


	@RequestMapping(value="/validateLogin",method=RequestMethod.GET)
	public String validateAccount(@RequestParam(value="username", required=true) String username,
			@RequestParam(value="password", required=true) String password,
			/*@RequestParam(value="totalamount", required=true) String totalamount,	*/	
			ModelMap map, HttpServletRequest request){{
				
				String totalamount=request.getParameter("totalAmount");
				System.out.println("amount="+totalamount);
			
				//map.addAttribute("amount",500.0);
				double paidAmount=Double.parseDouble(totalamount);
				BankAccount account= bankService.userValidation(username, password);
				//BankEventTransaction transaction= bankService.successfulTransaction(account.getAccountNo());
				map.addAttribute("username", account.getBankUserName());

				map.addAttribute("firstname", account.getAccountHolderFirstName());
				map.addAttribute("lastname", account.getAccountHolderLastName());
				map.addAttribute("accountnum", account.getAccountNo());
				map.addAttribute("availbalance", account.getAccountBalance());
				map.addAttribute("amount", paidAmount);
				
				request.setAttribute("account",account);
				
				
			
				return  "redirect:/BankWelcome";
			}

	}

	@RequestMapping(value="/successTransaction",method=RequestMethod.GET)
	public String successTransaction( ModelMap map, HttpServletRequest request){
		
        String username=request.getParameter("userName");
        String totalamount=request.getParameter("totalAmount");
        
		BankAccount account=new BankAccount();
		BankEventTransaction transaction=new BankEventTransaction();
		account=(BankAccount) request.getAttribute("account");
		System.out.println(account);
		//String username=account.getBankUserName();
		//String password=account.getBankPassword();
		
		//map.addAttribute("amount",500.0);
		double paidAmount=Double.parseDouble(totalamount);
		
		account=bankService.userTransaction(username, paidAmount);
		//if(account!=null){
		int accountNumber=account.getAccountNo();
		transaction= bankService.successfulTransaction(accountNumber);

		map.addAttribute("firstname", account.getAccountHolderFirstName());
		map.addAttribute("lastname", account.getAccountHolderLastName());
		map.addAttribute("accountnum", account.getAccountNo());
		
		map.addAttribute("transactionId", transaction.getTransactionId());
		map.addAttribute("paidamount", transaction.getAmountPaid());
		map.addAttribute("date", new Date());

		if(bankService.successfulTransaction(accountNumber)!=null){
			map.addAttribute("status", "Transaction Success");
		}
		else{
			map.addAttribute("status", "Transaction Failure");
		}

		//}
		return  "redirect:/TransactionSuccess";

	}


	@RequestMapping(value="/cancelTransaction",method=RequestMethod.GET)
	public String cancelTransaction(@RequestParam(value="transactionid", required=true) String transactionId,
			ModelMap map, HttpServletRequest request){{
				int transId=Integer.parseInt(transactionId);
				System.out.println(bankService.cancelTransaction(transId));
				return "redirect:/TransactionMsg";
			}
	}
}
