package com.bme.pojo;

import java.sql.Date;

//import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="bank_account")
public class BankAccount {

	
	@NotNull
	@Id	
	@Column(name="account_no")
	private int accountNo;

	
	@NotNull
	@Column(name="bank_username")
	private String bankUserName;

	@NotNull
	@Size(min = 6, max = 15)
	@Column(name="bank_password")
	private String bankPassword;

	@NotNull
	@Column(name="account_holder_firstname")
	private String accountHolderFirstName;
	
	@Column(name="account_holder_lastname")
	private String accountHolderLastName;
	
	@Column(name="account_holder_dateofbirth")
	private Date accountHolderDateOfBirth;

	@NotNull
	@Column(name="account_balance")
	private double accountBalance;

	@NotNull
	@Column(name="bank_name")
	private String bankName;
	
	@Column(name="create_date")
	private Date createDate;
	
	@Column(name="delete_date")
	private Date deleteDate;


	public BankAccount(){}


	public BankAccount(String bankUserName, String bankPassword,
			String accountHolderFirstName, String accountHolderLastName,
			Date accountHolderDateOfBirth, double accountBalance,
			String bankName, Date createDate) {
		super();

		this.bankUserName = bankUserName;
		this.bankPassword = bankPassword;
		this.accountHolderFirstName = accountHolderFirstName;
		this.accountHolderLastName = accountHolderLastName;
		this.accountHolderDateOfBirth = accountHolderDateOfBirth;
		this.accountBalance = accountBalance;
		this.bankName = bankName;
		this.createDate = createDate;
	}


	public BankAccount(int accountNo, String bankUserName, String bankPassword,
			String accountHolderFirstName, String accountHolderLastName,
			Date accountHolderDateOfBirth, double accountBalance,
			String bankName, Date createDate) {
		super();
		this.accountNo = accountNo;
		this.bankUserName = bankUserName;
		this.bankPassword = bankPassword;
		this.accountHolderFirstName = accountHolderFirstName;
		this.accountHolderLastName = accountHolderLastName;
		this.accountHolderDateOfBirth = accountHolderDateOfBirth;
		this.accountBalance = accountBalance;
		this.bankName = bankName;
		this.createDate = createDate;
	}


	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankUserName() {
		return bankUserName;
	}
	public void setBankUserName(String bankUserName) {
		this.bankUserName = bankUserName;
	}
	public String getBankPassword() {
		return bankPassword;
	}
	public void setBankPassword(String bankPassword) {
		this.bankPassword = bankPassword;
	}
	public String getAccountHolderFirstName() {
		return accountHolderFirstName;
	}
	public void setAccountHolderFirstName(String accountHolderFirstName) {
		this.accountHolderFirstName = accountHolderFirstName;
	}
	public String getAccountHolderLastName() {
		return accountHolderLastName;
	}
	public void setAccountHolderLastName(String accountHolderLastName) {
		this.accountHolderLastName = accountHolderLastName;
	}
	public Date getAccountHolderDateOfBirth() {
		return accountHolderDateOfBirth;
	}
	public void setAccountHolderDateOfBirth(Date accountHolderDateOfBirth) {
		this.accountHolderDateOfBirth = accountHolderDateOfBirth;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}


	public Date getDeleteDate() {
		return deleteDate;
	}


	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}


	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", bankUserName="
				+ bankUserName + ", bankPassword=" + bankPassword
				+ ", accountHolderFirstName=" + accountHolderFirstName
				+ ", accountHolderLastName=" + accountHolderLastName
				+ ", accountHolderDateOfBirth=" + accountHolderDateOfBirth
				+ ", accountBalance=" + accountBalance + ", bankName="
				+ bankName + ", createDate=" + createDate + ", deleteDate="
				+ deleteDate + "]";
	}



}


