package com.bme.pojo;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import antlr.debug.Event;


	@Entity
	@Table(name="booking")
	public class Booking {

		@Id
		@GeneratedValue
		private int bookingId;
		//private User user;
		private Event event;
		
		@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.LAZY)
		@JoinColumn(name="transactionId")
		private int transId;
		
		private double amountPaid;
		private Date createDate;
		private Date deleteDate;
		
		public Booking(){}
		
		
		
		public Booking(int bookingId, Event event, int transId,
				double amountPaid, Date createDate) {
			super();
			this.bookingId = bookingId;
			this.event = event;
			this.transId = transId;
			this.amountPaid = amountPaid;
			this.createDate = createDate;
		}



		public Booking(int bookingId, double amountPaid, Date createDate) {
			super();
			this.bookingId = bookingId;
			//this.user = user;
		
			this.amountPaid = amountPaid;
			this.createDate = createDate;
			
		}
		
		
		
		public int getBookingId() {
			return bookingId;
		}
		public void setBookingId(int bookingId) {
			this.bookingId = bookingId;
		}
		/*public User getUser() {
			return user;
		}
		public void setUser(User user) {
			this.user = user;
		}*/
		public Event getEvent() {
			return event;
		}
		public void setEvent(Event event) {
			this.event = event;
		}
		
		public double getAmountPaid() {
			return amountPaid;
		}
		public int getTransId() {
			return transId;
		}



		public void setTransId(int transId) {
			this.transId = transId;
		}



		public void setAmountPaid(double amountPaid) {
			this.amountPaid = amountPaid;
		}
		public Date getCreateDate() {
			return createDate;
		}
		public void setCreateDate(Date createDate) {
			this.createDate = createDate;
		}
		public Date getDeleteDate() {
			return deleteDate;
		}
		public void setDeleteDate(Date deleteDate) {
			this.deleteDate = deleteDate;
		}
		@Override
		public String toString() {
			return "Booking [bookingId=" + bookingId + ", amountPaid=" + amountPaid
					+ ", createDate=" + createDate + ", deleteDate=" + deleteDate
					+ "]";
		}
		
		
		

	}

