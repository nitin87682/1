package com.bme.pojo;

public enum BankName {
	HDFC,
	SBI,
	CITI

}
