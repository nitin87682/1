package com.bme.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="bank_event_transaction")
public class BankEventTransaction {

	@Id	
	@OneToOne(targetEntity=Booking.class)
	@GeneratedValue
	@Column(name="transaction_id")
	private int transactionId;
	
	@Column(name="sender_account_no")
	private int	senderAccountNo;
	
	@Column(name="receiver_account_no")
	private int receiverAccountNo;
	
	@Column(name="amount_paid")
	private double amountPaid;
	
	@Column(name="create_date")
	private Date createDate;
	
	@Column(name="delete_date")
	private Date deleteDate;


	public BankEventTransaction(){}

	
	
	public BankEventTransaction(int transactionId,
			int senderAccountNo, int receiverAccountNo, double amountPaid,
			Date createDate, Date deleteDate) {
		super();
		this.transactionId = transactionId;
		//this.booking = booking;
		this.senderAccountNo = senderAccountNo;
		this.receiverAccountNo = receiverAccountNo;
		this.amountPaid = amountPaid;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}


	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	
	/*public Booking getBooking() {
		return booking;
	}


	public void setBooking(Booking booking) {
		this.booking = booking;
	}*/


	public int getSenderAccountNo() {
		return senderAccountNo;
	}
	public void setSenderAccountNo(int senderAccountNo) {
		this.senderAccountNo = senderAccountNo;
	}
	
	public double getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public int getReceiverAccountNo() {
		return receiverAccountNo;
	}

	public void setReceiverAccountNo(int receiverAccountNo) {
		this.receiverAccountNo = receiverAccountNo;
	}



	



	@Override
	public String toString() {
		return "BankEventTransaction [transactionId=" + transactionId
				+ ", senderAccountNo="
				+ senderAccountNo + ", receiverAccountNo=" + receiverAccountNo
				+ ", amountPaid=" + amountPaid + ", createDate=" + createDate
				+ ", deleteDate=" + deleteDate + "]";
	}

	




}
