package com.bme.dao;

import java.util.List;


import com.bme.pojo.BankAccount;
import com.bme.pojo.BankEventTransaction;
import com.bme.pojo.Booking;

public interface IBankDao {

	public void saveAccount(BankAccount account);
	public List<BankAccount> getAllAccounts();
	public void deleteAccount(Integer accountNumber);
	//public void updateAccount(BankAccount account);
	public BankAccount getUserAccount(String username);
	//public void validUserTransaction(List<BankAccount> account,Booking booking);
	public boolean validUserTransaction(BankAccount account, double paidAmount);
	public boolean saveTransaction(BankEventTransaction transaction);
	public void cancellationTransaction(int transactionId);
	public BankEventTransaction getTransaction(int accountNumber );
}
