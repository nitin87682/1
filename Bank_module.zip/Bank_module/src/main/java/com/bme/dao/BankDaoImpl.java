package com.bme.dao;

import java.util.List;

import javax.persistence.Query;


import com.bme.pojo.BankAccount;
import com.bme.pojo.BankEventTransaction;
import com.bme.pojo.Booking;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class BankDaoImpl implements IBankDao {
	
	@Autowired
	private SessionFactory sessionFactory;


	public void saveAccount(BankAccount account) {
		sessionFactory.getCurrentSession().save(account);
	}
	
	@Override
	public List<BankAccount> getAllAccounts() {

		return sessionFactory.getCurrentSession().createQuery("from BankAccount").list();
	}


	public void deleteAccount(Integer accountNumber) {

		BankAccount account=(BankAccount) sessionFactory.getCurrentSession().get(BankAccount.class, accountNumber);
		if(account!=null)
			sessionFactory.getCurrentSession().delete(account);
	}

	public BankAccount getAccount(Integer accountNumber) {
		
		
		BankAccount account = (BankAccount) sessionFactory.getCurrentSession().get(BankAccount.class, accountNumber);
		return account;
	}


	public BankAccount getUserAccount(String username) {
		//BankAccount account = (BankAccount) sessionFactory.getCurrentSession().get(BankAccount.class,  username);
		int accountNumber=(int) sessionFactory.getCurrentSession().createQuery("select accountNo from BankAccount where bankUserName='"+username+"'").uniqueResult();
		BankAccount account = (BankAccount) sessionFactory.getCurrentSession().get(BankAccount.class,  accountNumber);
		return  account;
	}
	
	
	public boolean validUserTransaction(BankAccount account, double amountPaid) {
		
		//Booking getamount = (Booking) sessionFactory.getCurrentSession().get(Booking.class,  amountPaid);
		
		
		if(account.getAccountBalance()>=amountPaid){
			 account.setAccountBalance(account.getAccountBalance()-amountPaid);
			 sessionFactory.getCurrentSession().update(account);
			 return true;
		}
		return false;
	}

	
	public boolean saveTransaction(BankEventTransaction transaction) {
		sessionFactory.getCurrentSession().save(transaction);
		return true;
	}
	
	public BankEventTransaction getTransaction(int accountNumber ) {
		int transactionId=(int) sessionFactory.getCurrentSession().createQuery("select transactionId from BankEventTransaction where senderAccountNo="+accountNumber).uniqueResult();
		BankEventTransaction transaction = (BankEventTransaction) sessionFactory.getCurrentSession().get(BankEventTransaction.class, transactionId);
		return transaction;
	}

	public void cancellationTransaction(int transactionId)
	{
		BankEventTransaction transaction = (BankEventTransaction) sessionFactory.getCurrentSession().get(BankEventTransaction.class,  transactionId);
		int accno=transaction.getSenderAccountNo();
		BankAccount account = (BankAccount) sessionFactory.getCurrentSession().get(BankAccount.class, accno);
		account.setAccountBalance(account.getAccountBalance()+transaction.getAmountPaid());
		 sessionFactory.getCurrentSession().update(account);
		transaction.setAmountPaid(0);
		 sessionFactory.getCurrentSession().update(transaction);
		
		
		//return transaction;
		
	}
	}
	

	
	


