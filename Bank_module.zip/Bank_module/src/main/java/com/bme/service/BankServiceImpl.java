package com.bme.service;


import java.util.Date;
import java.util.List;

import com.bme.dao.IBankDao;

import com.bme.pojo.BankAccount;
import com.bme.pojo.BankEventTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service

public class BankServiceImpl implements IBankService {
	@Autowired
	private IBankDao bankDao;

	@Transactional
	public void saveAccount(BankAccount account) {
		bankDao.saveAccount(account);


	}
	@Transactional
	public List<BankAccount> getAllAccounts() {
		return bankDao.getAllAccounts();
	}


	@Transactional
	public void deleteAccount(Integer accountNumber) {
		bankDao.deleteAccount(accountNumber);	

	}
	
	public BankAccount userValidation(String username, String password) {


		BankAccount account= new BankAccount();
		
		account=bankDao.getUserAccount(username);
		

	if(account.getBankUserName()!=null)
		{
			
			if(password.equals(((BankAccount) account).getBankPassword())){
				
				return account;
			}
		}
	return null;
	}
	
	public BankAccount userTransaction(String username,double paidAmount) {

		BankAccount account= new BankAccount();
		
		account=bankDao.getUserAccount(username);
				if(bankDao.validUserTransaction(account,paidAmount)){
				
					BankEventTransaction transaction=new BankEventTransaction();
					
					transaction.setAmountPaid(paidAmount);
					transaction.setSenderAccountNo(account.getAccountNo());
					transaction.setCreateDate(new Date());
					transaction.setReceiverAccountNo(22222222);
					bankDao.saveTransaction(transaction);
					/*return account;*/
				}else
				{
					BankEventTransaction transaction=new BankEventTransaction();
					transaction.setAmountPaid(0);
					transaction.setSenderAccountNo(account.getAccountNo());
					transaction.setCreateDate(new Date());
					bankDao.saveTransaction(transaction);
				}
		return account;
	}



	public BankEventTransaction successfulTransaction(int accountNumber ){
		BankEventTransaction transaction=bankDao.getTransaction(accountNumber);
		return transaction;
	}
	
	public String cancelTransaction(int transactionId)
	{
		bankDao.cancellationTransaction(transactionId);
		return "Cancellation successful!!";
	}

	

}

