package com.bme.service;

import java.util.List;

import com.bme.pojo.BankAccount;
import com.bme.pojo.BankEventTransaction;
import com.bme.pojo.Booking;



public interface IBankService {
	public void saveAccount(BankAccount account);
	public List<BankAccount> getAllAccounts();
	public void deleteAccount(Integer accountNumber);
	public BankAccount userValidation(String username, String password);
	public BankAccount userTransaction(String username, double paidAmount);
	public String cancelTransaction(int transactionId);
	public BankEventTransaction successfulTransaction(int accountNumber );
	
}
