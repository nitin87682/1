package com.bme.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import com.bme.pojo.Comment;
import com.bme.pojo.Rating;
import com.bme.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CommentController {
	
	@Autowired
	private CommentService commentService;
	private Comment searchComment=null;

	@RequestMapping("/comment")
	public String showCommentPage(Map<String, Object> map){
		
			//	map.put( "comment", new Comment());
				
				
				return "employee";
	}

	
	
	@RequestMapping(value={"/showComment"},method=RequestMethod.GET)
	public @ResponseBody List<Comment> showComment(@PathVariable("eventId")@RequestParam("eventId") String eventId){
		int eId=Integer.parseInt(eventId);
		List<Comment> comments= new  ArrayList<Comment>(); 
			comments =	commentService.getAllComments(eId);
			System.out.println(comments);
		return comments ;
	}
	
	
	
	@RequestMapping(value={"/saveComment"},method=RequestMethod.POST)
    public @ResponseBody String saveComment(@RequestBody Comment comment){



           //Adding from the URL
          /* Comment comment=new Comment();
           comment.setCommentId(commentId);
           comment.setEventId(eventId);
           comment.setUserId(userId);
           comment.setText(text);
           comment.setTime(new Date());*/ comment.setTime(new Date());
           return commentService.saveComment(comment);
    }


	
	@RequestMapping("/deleteComment/{commentId}")
	public String deleteComment(@PathVariable("commentId")@RequestParam("commentId") String commentId){
		commentService.deleteComment(Integer.parseInt(commentId));
		return "redirect:/empForm";
	}
	

	
	

	
}