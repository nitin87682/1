package com.bme.dao;

import java.util.List;

import com.bme.pojo.Comment;

public interface CommentDao {

	public boolean saveComment(Comment comment);
	
	public List<Comment> getAllComments(Integer eventId);
	
	public void deleteComment(Integer commentId);
	
	public Comment searchComment(Integer commentId);
}
