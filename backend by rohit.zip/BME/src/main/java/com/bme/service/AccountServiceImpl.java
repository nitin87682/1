package com.bme.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bme.dao.AccountDao;
import com.bme.pojo.Event;

@Service
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	private AccountDao accountDao;

	@Transactional
	public void saveAccount(Event event) {
		
		 accountDao.saveAccount(event);
	}
		
	
//accountDao.saveAccount(event);
		


	@Transactional
	public List<Event> getAllAccounts() {
		return accountDao.getAllAccounts();
	}
	
	@Transactional
	public List<Event> getAllUpcomingEvents() {
		System.out.println("IN SERVICE");
		return accountDao.getAllUpcomingEvents();
	}
	@Transactional
	public String deleteAcount(Integer eventId) {
		accountDao.deleteAcount(eventId);
		return "Deleted Successfully";
	}

	/*@Transactional
	public void deleteAcount(Integer eventId) {
		accountDao.deleteAcount(eventId);
	}*/

	
	@Transactional
	public Event searchEvent(Integer eventId) {
		
		return accountDao.searchEvent(eventId);
	}

	@Transactional
	public List<Event> searchEventByCertificate(String cer) {
		return accountDao.searchEventByCertificate(cer);
		
	}
	@Transactional
	public List<Event> searchEventByPerformer(String cer) {
		return accountDao.searchEventByPerformer(cer);
		
	}	@Transactional
	public List<Event> searchEventByVenue(String cer) {
		return accountDao.searchEventByVenue(cer);
		
	}	@Transactional
	public List<Event> searchEventByCategory(String cer) {
		return accountDao.searchEventByCategory(cer);
		
	}
}
