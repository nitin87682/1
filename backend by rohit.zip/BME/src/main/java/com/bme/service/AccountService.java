package com.bme.service;

import java.util.List;


import com.bme.pojo.Event;



public interface AccountService {
	public void saveAccount(Event event);
	public List<Event> getAllAccounts() ;
	public String deleteAcount(Integer eventId);
	public Event searchEvent(Integer eventId);
	public List<Event> searchEventByCertificate(String cer);
	public List<Event> searchEventByPerformer(String cer);
	public List<Event> searchEventByVenue(String cer);
	public List<Event> searchEventByCategory(String cer);
	public List<Event> getAllUpcomingEvents();
}
