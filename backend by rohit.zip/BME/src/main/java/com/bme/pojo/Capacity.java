package com.bme.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Capacity {

	@Id
	@GeneratedValue
	@OneToOne(targetEntity=Event.class)
	@Column(name="capacity_id")
	private int capacityId;
	@Column(name="silver_capacity")
	private int silverCapacity;
	@Column(name="gold_capacity")
	private int goldCapacity;
	@Column(name="platinum_capacity")
	private int platinumCapacity;
	@Column(name="silver_current_capacity")
	private int silverCurrentCapacity;
	@Column(name="gold_current_capacity")
	private int goldCurrentCapacity;
	@Column(name="platinum_current_capacity")
	private int platinumCurrentCapacity;
	public int getCapacityId() {
		return capacityId;
	}
	public void setCapacityId(int capacityId) {
		this.capacityId = capacityId;
	}
	public int getSilverCapacity() {
		return silverCapacity;
	}
	public void setSilverCapacity(int silverCapacity) {
		this.silverCapacity = silverCapacity;
	}
	public int getGoldCapacity() {
		return goldCapacity;
	}
	public void setGoldCapacity(int goldCapacity) {
		this.goldCapacity = goldCapacity;
	}
	public int getPlatinumCapacity() {
		return platinumCapacity;
	}
	public void setPlatinumCapacity(int platinumCapacity) {
		this.platinumCapacity = platinumCapacity;
	}
	public int getSilverCurrentCapacity() {
		return silverCurrentCapacity;
	}
	public void setSilverCurrentCapacity(int silverCurrentCapacity) {
		this.silverCurrentCapacity = silverCurrentCapacity;
	}
	public int getGoldCurrentCapacity() {
		return goldCurrentCapacity;
	}
	public void setGoldCurrentCapacity(int goldCurrentCapacity) {
		this.goldCurrentCapacity = goldCurrentCapacity;
	}
	public int getPlatinumCurrentCapacity() {
		return platinumCurrentCapacity;
	}
	public void setPlatinumCurrentCapacity(int platinumCurrentCapacity) {
		this.platinumCurrentCapacity = platinumCurrentCapacity;
	}
	@Override
	public String toString() {
		return "Capacity [capacityId=" + capacityId + ", silverCapacity="
				+ silverCapacity + ", goldCapacity=" + goldCapacity
				+ ", platinumCapacity=" + platinumCapacity
				+ ", silverCurrentCapacity=" + silverCurrentCapacity
				+ ", goldCurrentCapacity=" + goldCurrentCapacity
				+ ", platinumCurrentCapacity=" + platinumCurrentCapacity + "]";
	}
	public Capacity(int capacityId, int silverCapacity, int goldCapacity,
			int platinumCapacity, int silverCurrentCapacity,
			int goldCurrentCapacity, int platinumCurrentCapacity) {
		super();
		this.capacityId = capacityId;
		this.silverCapacity = silverCapacity;
		this.goldCapacity = goldCapacity;
		this.platinumCapacity = platinumCapacity;
		this.silverCurrentCapacity = silverCurrentCapacity;
		this.goldCurrentCapacity = goldCurrentCapacity;
		this.platinumCurrentCapacity = platinumCurrentCapacity;
	}
	public Capacity() {}
	
	
}