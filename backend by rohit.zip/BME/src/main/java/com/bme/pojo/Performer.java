package com.bme.pojo;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Performer {

	@Id
	@GeneratedValue
	@OneToOne(targetEntity=Event.class)
	@Column(name="performer_id")
	private int performerId;
	@Column(name="performer_first_name")
	private String performerFirstName;
	@Column(name="performer_last_name")
	private String performerLastName;
	@Column(name="performer_dob")
	private Date performerDob;
	@Column(name="create_date")
	private Date createDate;
	@Column(name="delete_date")
	private Date deleteDate;
	public int getPerformerId() {
		return performerId;
	}
	public void setPerformerId(int performerId) {
		this.performerId = performerId;
	}
	public String getPerformerFirstName() {
		return performerFirstName;
	}
	public void setPerformerFirstName(String performerFirstName) {
		this.performerFirstName = performerFirstName;
	}
	public String getPerformerLastName() {
		return performerLastName;
	}
	public void setPerformerLastName(String performerLastName) {
		this.performerLastName = performerLastName;
	}
	public Date getPerformerDob() {
		return performerDob;
	}
	public void setPerformerDob(Date performerDob) {
		this.performerDob = performerDob;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	@Override
	public String toString() {
		return "Performer [performerId=" + performerId
				+ ", performerFirstName=" + performerFirstName
				+ ", performerLastName=" + performerLastName
				+ ", performerDob=" + performerDob + ", createDate="
				+ createDate + ", deleteDate=" + deleteDate + "]";
	}
	public Performer(int performerId, String performerFirstName,
			String performerLastName, Date performerDob, Date createDate,
			Date deleteDate) {
		super();
		this.performerId = performerId;
		this.performerFirstName = performerFirstName;
		this.performerLastName = performerLastName;
		this.performerDob = performerDob;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}
	public Performer() {}
	
}
