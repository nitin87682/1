package com.bme.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Price {

@Id
@GeneratedValue
@OneToOne(targetEntity=Event.class)
@Column(name="price_id")
	private int priceId;
@Column(name="price_silver")
	private double priceSilver;
@Column(name="price_gold")
	private double priceGold;
@Column(name="price_platinum")
	private double pricePlatinum;
	public int getPriceId() {
		return priceId;
	}
	public void setPriceId(int priceId) {
		this.priceId = priceId;
	}
	public double getPriceSilver() {
		return priceSilver;
	}
	public void setPriceSilver(double priceSilver) {
		this.priceSilver = priceSilver;
	}
	public double getPriceGold() {
		return priceGold;
	}
	public void setPriceGold(double priceGold) {
		this.priceGold = priceGold;
	}
	public double getPricePlatinum() {
		return pricePlatinum;
	}
	public void setPricePlatinum(double pricePlatinum) {
		this.pricePlatinum = pricePlatinum;
	}
	@Override
	public String toString() {
		return "Price [priceId=" + priceId + ", priceSilver=" + priceSilver
				+ ", priceGold=" + priceGold + ", pricePlatinum="
				+ pricePlatinum + "]";
	}
	public Price(int priceId, double priceSilver, double priceGold,
			double pricePlatinum) {
		super();
		this.priceId = priceId;
		this.priceSilver = priceSilver;
		this.priceGold = priceGold;
		this.pricePlatinum = pricePlatinum;
	}
	

	public Price() {}

}
