package com.bme.pojo;

import java.sql.Time;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Event {

	@Id
	@GeneratedValue
	@Column(name="event_id")
	private int eventId;
	@Column(name="event_name")
	private String eventName;
	@Column(name="event_date")
	private java.sql.Date eventDate;
	@Column(name="event_certificate")
	private String eventCertificate;
	@Column(name="description")
	private String description;
	@Column(name="event_status")
	private String eventStatus;
	@Column(name="event_time")
	private Time eventTime;
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
    @JoinColumn(name="organiser_id")
	private Organiser organiser;
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="capacity_id")
	private Capacity capacity;
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="price_id")
	private Price price;
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="venue_id")
	private Venue venue;
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="performer_id")
	private Performer performer;
	@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="category_id")
	private Category category;
	@Column(name="create_date")
	private Date createDate;
	@Column(name="delete_date")
	private Date deleteDate;
	@Column(name="event_image_url")
	private String eventImageUrl;
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public java.sql.Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(java.sql.Date eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventCertificate() {
		return eventCertificate;
	}
	public void setEventCertificate(String eventCertificate) {
		this.eventCertificate = eventCertificate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public Time getEventTime() {
		return eventTime;
	}
	public void setEventTime(Time eventTime) {
		this.eventTime = eventTime;
	}
	public Organiser getOrganiser() {
		return organiser;
	}
	public void setOrganiser(Organiser organiser) {
		this.organiser = organiser;
	}
	public Capacity getCapacity() {
		return capacity;
	}
	public void setCapacity(Capacity capacity) {
		this.capacity = capacity;
	}
	public Price getPrice() {
		return price;
	}
	public void setPrice(Price price) {
		this.price = price;
	}
	public Venue getVenue() {
		return venue;
	}
	public void setVenue(Venue venue) {
		this.venue = venue;
	}
	public Performer getPerformer() {
		return performer;
	}
	public void setPerformer(Performer performer) {
		this.performer = performer;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public String getEventImageUrl() {
		return eventImageUrl;
	}
	public void setEventImageUrl(String eventImageUrl) {
		this.eventImageUrl = eventImageUrl;
	}
	public Event(int eventId, String eventName, java.sql.Date eventDate,
			String eventCertificate, String description, String eventStatus,
			Time eventTime, Organiser organiser, Capacity capacity,
			Price price, Venue venue, Performer performer, Category category,
			Date createDate, Date deleteDate, String eventImageUrl) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.eventDate = eventDate;
		this.eventCertificate = eventCertificate;
		this.description = description;
		this.eventStatus = eventStatus;
		this.eventTime = eventTime;
		this.organiser = organiser;
		this.capacity = capacity;
		this.price = price;
		this.venue = venue;
		this.performer = performer;
		this.category = category;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.eventImageUrl = eventImageUrl;
	}
	public Event() {}
	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eventName=" + eventName
				+ ", eventDate=" + eventDate + ", eventCertificate="
				+ eventCertificate + ", description=" + description
				+ ", eventStatus=" + eventStatus + ", eventTime=" + eventTime
				+ ", organiser=" + organiser + ", capacity=" + capacity
				+ ", price=" + price + ", venue=" + venue + ", performer="
				+ performer + ", category=" + category + ", createDate="
				+ createDate + ", deleteDate=" + deleteDate
				+ ", eventImageUrl=" + eventImageUrl + "]";
	}
	
}



