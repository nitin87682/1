package com.bme.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bme.pojo.Event;

@Repository
public class AccountDaoImp implements AccountDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	/*public boolean saveAccount(Event event) {
		event.setCreateDate(new Date());
		
		int status =(Integer) sessionFactory.getCurrentSession().save(event);
		if(status>=1)
		{
			return true;
		}
		
		return false;	
	}*/
	
	
	
	/*public void deleteAcount(Integer eventId) {
		int status= sessionFactory.getCurrentSession().delete(eventId);
		if(status>=1)
		{
			return true;
		}
		return false;
	}
	
		Event event=(Event) sessionFactory.getCurrentSession().get(Event.class, eventId);
		if(event!=null)
			sessionFactory.getCurrentSession().delete(event);
	}*/
	@Override
	public void deleteAcount(Integer eventId) {
		Event event=(Event) sessionFactory.getCurrentSession().get(Event.class, eventId);
		event.setDeleteDate(new Date());
		if(event!=null)
			sessionFactory.getCurrentSession().delete(event);
		
		
	}
	
	public void saveAccount(Event event) {
		event.setCreateDate(new Date());
		sessionFactory.getCurrentSession().save(event);


	}
	

	public List<Event> getAllAccounts() {
		
		return sessionFactory.getCurrentSession().createQuery("from Event").list();
	}
	
	
public List<Event> getAllUpcomingEvents() {
		System.out.println("IN DAO");
		return sessionFactory.getCurrentSession().createQuery("from Event where eventDate>SYSDATE()").list();
	}
	

	
	
	
	public Event searchEvent(Integer eventId) {
		Event emp=(Event) sessionFactory.getCurrentSession().get(Event.class, eventId);
		Event emp1=(Event) sessionFactory.getCurrentSession().get(Event.class, eventId);
		if(emp1!=null)
			sessionFactory.getCurrentSession().delete(emp1);
		
		return emp;
	}

	public List<Event> searchEventByCertificate(String cer) {
		
		return sessionFactory.getCurrentSession().createQuery(" from  Event where eventCertificate='"+cer+"'").list();
		
	}public List<Event> searchEventByPerformer(String cer) {
	
		return sessionFactory.getCurrentSession().createQuery(" from  Event where performer.performerFirstName='"+cer+"'").list();
		
	}public List<Event> searchEventByVenue(String cer) {
		
		return sessionFactory.getCurrentSession().createQuery(" from  Event where venue.venueName='"+cer+"'").list();
		
	}public List<Event> searchEventByCategory(String cer) {
		
		return sessionFactory.getCurrentSession().createQuery(" from  Event where category.categoryName='"+cer+"'").list();
		
	}
}
