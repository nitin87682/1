package com.bme.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bme.pojo.Event;
import com.bme.service.AccountService;

@Controller
public class AccountContoller {
	
	@Autowired
	private AccountService accountService;
	private Event searchEvent=null;
	@RequestMapping("/saveOrUpdate")
	public String showAccountPage(Map<String, Object> map){
		List<Event> events= accountService.getAllAccounts();
		
		
		map.put("emps",events);
		map.put("empSearch",searchEvent);
		map.put("event",new Event());
		map.put("eve",new Event());
		
		if(searchEvent!=null){
			map.put("emp", searchEvent);
				
		}
				return "accountRegister";
	}
	
	
	
	@RequestMapping("/upcomingEvents")
	public String showUpcomingEvents(Map<String, Object> map){
		List<Event> events= accountService.getAllUpcomingEvents();
		
		
		map.put("emps",events);
		map.put("empSearch",searchEvent);
		map.put("event",new Event());
		map.put("eve",new Event());
		
		if(searchEvent!=null){
			map.put("emp", searchEvent);
				
		}
				return "upcomingEvents";
	}
	
	
	
	
	
	
	
	
	
	

	@RequestMapping(value={"/saveEvent","/update"},method=RequestMethod.POST)
	public String showEventDetails(Map<String, Object> map,
			@Valid @ModelAttribute("emp") Event emp, BindingResult result){
		List<Event> events= accountService.getAllAccounts();
		map.put("emps",events);
		map.put("empSearch",searchEvent);
		if(result.hasErrors()){
			
			
			return "accountRegister";
		}
		else{
			searchEvent=null;
			accountService.saveAccount(emp);
			
			
			return "redirect:/saveOrUpdate";
		}
	}
	
	
	
	
	/*@RequestMapping(value={"/saveEvent"},method=RequestMethod.POST)
	public @ResponseBody String showEventDetails(
			@RequestBody Event emp){
			return accountService.saveAccount(emp);
	}*/
	
	
	/*
	@RequestMapping("/delete/{eventId}")
	public String deleteEvent(@PathVariable("eventId") Integer eventId){
		accountService.deleteAcount(eventId);
		return "redirect:/saveOrUpdate";
	}*/

	@RequestMapping("/delete/{eventId}")
	public @ResponseBody String deleteEvent(@PathVariable("eventId") Integer eventId){
		return accountService.deleteAcount(eventId);
		//return "redirect:/faq";
	}

	
	@RequestMapping("/update/{eventId}")
	public String  updateEvent(@PathVariable("eventId") Integer eventId){
		Event emp=accountService.searchEvent(eventId);
		searchEvent=emp;
		return"redirect:/saveOrUpdate";
	}
	
	@RequestMapping(value="/searchByCertificate", method=RequestMethod.GET)
	public @ResponseBody List<Event>   searchEventByCerticate(@ModelAttribute("eve") Event emp, BindingResult result){
		List<Event> emp1=accountService.searchEventByCertificate(emp.getEventCertificate());
		searchEvent=(Event) emp;
		
System.out.println(emp1);		
		


return emp1;
	}
	
	@RequestMapping(value="/searchByPerformer", method=RequestMethod.GET)
	public @ResponseBody List<Event>  searchEventByPerformer(@ModelAttribute("eve") Event emp, BindingResult result){
		List<Event> emp1=accountService.searchEventByPerformer(emp.getPerformer().getPerformerFirstName());
		searchEvent=(Event) emp;
		
System.out.println(emp1);		
		
//System.out.println(emp.getEventCertificate());

return emp1;
	}
	
	@RequestMapping(value="/searchByVenue", method=RequestMethod.GET)
	public @ResponseBody List<Event>  searchEventByVenue(@ModelAttribute("eve") Event emp, BindingResult result){
		List<Event> emp1=accountService.searchEventByVenue(emp.getVenue().getVenueName());
		searchEvent=(Event) emp;
		
System.out.println(emp1);		
		
//System.out.println(emp.getEventCertificate());

return emp1;
	}
	
	@RequestMapping(value="/searchByCategory", method=RequestMethod.GET)
	public @ResponseBody List<Event>  searchEventByCategory(@ModelAttribute("eve") Event emp, BindingResult result){
		List<Event> emp1=accountService.searchEventByCategory(emp.getCategory().getCategoryName());
		searchEvent=(Event) emp;
		
System.out.println(emp1);		
		
//System.out.println(emp.getEventCertificate());

return emp1;
	}
	
	
	
	
	/* 
	@RequestMapping(value="/transactions", method=RequestMethod.POST)
	public String transactions(@Valid @ModelAttribute("event") Event event,Map<String, Object> map)
	{
	Date ed=event.getEventDate();
	System.out.println(ed);
	// List<Event> events=accountService.transactions(eventDate);
	System.out.println(accountService.transactions(ed));
	map.put("tran", accountService.transactions(ed));
	return "accountRegister";
	}*/
	
	 

	
	
	
	
	
	
	
}
