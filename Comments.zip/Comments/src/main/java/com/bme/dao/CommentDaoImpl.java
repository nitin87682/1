package com.bme.dao;

import java.util.Date;
import java.util.List;

import com.bme.pojo.Comment;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CommentDaoImpl implements CommentDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	public boolean saveComment(Comment comment) {

		int status =(Integer) sessionFactory.getCurrentSession().save(comment);
		if(status>=1)
		{
			return true;
		}
		
		return false;	
	}

	
	public List<Comment> getAllComments(Integer eventId) {
		
		return sessionFactory.getCurrentSession().createQuery("SELECT c.comment_id ,c.comment,c.event_id,c.user_id,c.create_date,u.first_name,u.last_name FROM COMMENT c , USER u WHERE c.user_id=u.user_id and event_id="+eventId).list();
	}

	
	public void deleteComment(Integer commentId) {
		Comment cmt=(Comment) sessionFactory.getCurrentSession().get(Comment.class, commentId);
		if(cmt!=null)
			sessionFactory.getCurrentSession().delete(cmt);
	}

	
	public Comment searchComment(Integer commentId) {
		Comment cmt=(Comment) sessionFactory.getCurrentSession().get(Comment.class, commentId);
		return cmt;
	}
	
}
