package com.bme.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bme.pojo.Rating;

import com.bme.service.IRatingService;

@Controller
public class RatingContoller {
	
	@Autowired
	private IRatingService ratingService;
	
	
	@RequestMapping("/rating")
	public String showRatingPage(Map<String, Object> map){
		
				map.put( "rating", new Rating());
				
				
				return "accountRegister";
	}
	
	@RequestMapping(value="/saveRating",method=RequestMethod.POST)
	public @ResponseBody  String saveRating(@RequestBody Rating rating){
			
			 return ratingService.addRating(rating);
		
	
	}
	

	@RequestMapping(value="/showLikes/{eventId}" ,method=RequestMethod.GET)
	public String showLikes(@PathVariable("eventId") int eId,Map<String, Object> map){
		//int eId=rating.getEventId();
		
		
		
		Integer count=ratingService.showNoOfLikes(eId);
		String count1=count.toString();
	
		
		Map<Integer, String> maps=new HashMap<>();
		maps.put(1,count1);
		
		map.put("test",maps.values());
		 return "accountRegister";
		
		
	}
	
	@RequestMapping(value="/showDislikes" ,method=RequestMethod.POST)
	public String showDislikes(@Valid @ModelAttribute("rating") Rating rating,BindingResult result,Map<String, Object> map){
		int eId=rating.getEventId();
		System.out.println(eId);
		Integer count=ratingService.showNoOfDislikes(eId);
		String count1=count.toString();
		Map<Integer, String> maps=new HashMap<>();
		maps.put(1,count1);
		map.put("test1",maps.values());
		 return "accountRegister";
		
		
	}
	
}
