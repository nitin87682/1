package com.bme.service;

import java.util.List;

import com.bme.pojo.Comment;

public interface CommentService {
	public String saveComment(Comment comment);
	public List<Comment> getAllComments(Integer eventId);
	public void deleteComment(Integer commentId);
	public Comment searchComment(Integer commentId);
}
