package com.bme.service;

import java.util.List;

import com.bme.dao.CommentDao;
import com.bme.pojo.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CommentServiceImpl implements CommentService{

	@Autowired
	private CommentDao commentDao;
	
	@Transactional
	public String saveComment(Comment comment) {
		if(commentDao.saveComment(comment))
		{
			return "Comment Added Successfully";
			
		}
		return "Comment Failed";
	}

	@Transactional
	public List<Comment> getAllComments(Integer eventId) {
		
		return commentDao.getAllComments(eventId);
	}

	@Transactional
	public void deleteComment(Integer commentId) {
		commentDao.deleteComment(commentId);
	}

	@Transactional
	public Comment searchComment(Integer commentId) {
		
		return commentDao.searchComment(commentId);
	}

}
