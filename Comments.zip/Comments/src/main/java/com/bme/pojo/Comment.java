package com.bme.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Comment {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	@Column(name="comment_id")
	private int commentId;
	@Column(name="event_id")
	private int eventId;
	@Column(name="user_id")
    private int userId;  
	@Column(name="comment")
	private String text;
	/*@Column(name="img_url")
	private String imgURL;
*/	@Column(name="create_date")

	private Date time;
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public Comment(int commentId, int eventId, int userId, String text,
			 Date time) {
		super();
		this.commentId = commentId;
		this.eventId = eventId;
		this.userId = userId;
		this.text = text;
	
		this.time = time;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public Comment(){}
	@Override
	public String toString() {
		return "Employee [commentId=" + commentId + ", eventId=" + eventId
				+ ", userId=" + userId + ", text=" + text + ",  time=" + time + "]";
	}
	
}
	