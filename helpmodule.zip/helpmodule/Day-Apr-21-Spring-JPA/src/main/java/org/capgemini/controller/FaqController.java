package org.capgemini.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.capgemini.pojo.Faq;
import org.capgemini.pojo.FeedBack;
import org.capgemini.service.IFaqService;
import org.capgemini.service.IFeedBackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FaqController {
	
	@Autowired
	private IFaqService faqService;
	private Faq SearchFaq=null;

	@Autowired
	private IFeedBackService feedBackService;

	@RequestMapping("/feedBack")
	public String showFeedBackPage(Map<String, Object> map){

		map.put( "feedBack", new FeedBack());
		map.put("feedBacks", feedBackService.GetAllFeedBack());

		return "feedBackRegister";
	}
	@RequestMapping(value="/saveFeedBack",method=RequestMethod.POST)
	public ModelAndView saveFeedBack(@Valid @ModelAttribute("feedBack") FeedBack feedBack,
			BindingResult result){

		if(!result.hasErrors()){
			System.out.println(feedBack);
			feedBackService.saveFeedBack(feedBack);
			return new ModelAndView("redirect:feedBack");
		}else
		{
			return new ModelAndView("feedBackRegister");
		}

	}
	@RequestMapping("/delete1/{feedbackId}")
	public String deleteAccount1(@PathVariable("feedbackId") Integer fdId){
		feedBackService.deleteFeedBack(fdId);
		return "redirect:/feedBack";
	}

	
	
	@RequestMapping("/faq")
	 public String showFaqPage(Map<String, Object> map){

		List<Faq> faqs= faqService.GetAllFaq();
		map.put( "faqs", faqs);
		map.put("faqSearch",SearchFaq);
		map.put( "faq", new Faq());
		
		if(SearchFaq!=null){
			map.put("faq", SearchFaq);
				
		}

		return "faqRegister"; 
	}
	
	
	
	

	@RequestMapping(value="/saveFaq",method=RequestMethod.GET)
	 public String saveFaq(@Valid @ModelAttribute("faq") Faq faq,
			BindingResult result){

		
	
		if(!result.hasErrors()){
			System.out.println("faq details");
			System.out.println(faq);
			faqService.saveFaq(faq);
			return"redirect:faq";
		}else
		{
			return "faqRegister";
		}

	}
	@RequestMapping("/delete/{faqId}")
	 public String deleteAccount(@PathVariable("faqId") Integer fqId){
		faqService.deleteFaq(fqId);
		return "redirect:/faq";
	}

	

	@RequestMapping(value={"/saveFaq","/update"},method=RequestMethod.POST)
	 public String showfaqDetails(Map<String, Object> map,
			@Valid @ModelAttribute("faq") Faq faq, BindingResult result){
		List<Faq> faqs= faqService.GetAllFaq();
		map.put("faqs",faqs);
		map.put("faqSearch",SearchFaq);
		if(result.hasErrors()){

			return "faqRegister";
		}
		else{
			SearchFaq=null;
			faqService.saveFaq(faq);
			return "redirect:/faq";
		}
	}

	@RequestMapping("/update/{faqId}")
	 public String  updateFaq(@PathVariable("faqId") Integer faqId){
		Faq faq=faqService.SearchFaq(faqId);
		SearchFaq=faq;
		System.out.println("faq update details");
		
		System.out.println(faq);
		return"redirect:/faq";
		}
	
	

	
}
