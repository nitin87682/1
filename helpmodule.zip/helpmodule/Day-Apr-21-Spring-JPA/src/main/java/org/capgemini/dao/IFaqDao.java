package org.capgemini.dao;

import java.util.List;

import org.capgemini.pojo.Faq;


public interface IFaqDao {
	public void saveFaq(Faq faq);
	public List<Faq> GetAllFaq() ;
	public void deleteFaq(Integer faqId);
	public Faq SearchFaq(Integer faqId); 
	public void updateFaq(Faq faq);
}
