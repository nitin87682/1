package org.capgemini.dao;

import java.util.List;

import org.capgemini.pojo.FeedBack;

public interface IFeedBackDao {

	public void saveFeedBack(FeedBack fb);
	public List<FeedBack> GetAllFeedBack() ;
	public void deleteFeedBack(Integer feedBackId); 
}
