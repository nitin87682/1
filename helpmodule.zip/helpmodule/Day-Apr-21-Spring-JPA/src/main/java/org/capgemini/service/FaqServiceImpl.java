package org.capgemini.service;

import java.util.List;


import org.capgemini.dao.IFaqDao;
import org.capgemini.pojo.Faq;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class FaqServiceImpl implements IFaqService {
	@Autowired
	private IFaqDao faqdao;

	@Transactional
	public void saveFaq(Faq faq) {
		faqdao.saveFaq(faq);
		
	}

	@Transactional
	public List<Faq> GetAllFaq() {
		return faqdao.GetAllFaq();
	}

	@Transactional
	public void deleteFaq(Integer faqId) {
		faqdao.deleteFaq(faqId);
		
	}

	@Transactional
	public Faq SearchFaq(Integer faqId) {
		
		return faqdao.SearchFaq(faqId);
		
	}
	
	@Transactional
	public void updateFaq(Faq faq) {
		faqdao.updateFaq(faq);
		
	}


}
