package org.capgemini.service;

import java.util.List;

import org.capgemini.dao.IFeedBackDao;
import org.capgemini.pojo.FeedBack;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class FeedBackServiceImpl implements IFeedBackService {
	@Autowired
	private IFeedBackDao fbdao;
	@Transactional
	public void saveFeedBack(FeedBack fb) {
		fbdao.saveFeedBack(fb);
		
	}

	@Transactional
	public List<FeedBack> GetAllFeedBack() {
		return fbdao.GetAllFeedBack();
	}

	@Transactional
	public void deleteFeedBack(Integer feedBackId) {
		fbdao.deleteFeedBack(feedBackId);
		
	}
	

}
