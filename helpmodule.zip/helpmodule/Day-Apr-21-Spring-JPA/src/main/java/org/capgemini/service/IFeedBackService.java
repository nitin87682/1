package org.capgemini.service;

import java.util.List;

import org.capgemini.pojo.FeedBack;


public interface IFeedBackService {
	public void saveFeedBack(FeedBack fb);
	public List<FeedBack> GetAllFeedBack() ;
	public void deleteFeedBack(Integer feedBackId);
	

}
