package org.capgemini.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;



@Entity
public class FeedBack {
	@Id
	@GeneratedValue
	@Column(name = "feedback_id")
	private int feedbackId;
	@Column(name = "email_id")
	private String emailId;
	@Column(name = "name")
	private String name;
	@Column(name = "feedback_content")
	private String feedbackContent;
	@Column(name = "create_date")
	private Date createDate;
	@Column(name = "delete_date")
	private Date deleteDate;
	@Override
	public String toString() {
		return "FeedBack [feedbackId=" + feedbackId + ", emailId=" + emailId
				+ ", name=" + name + ", feedbackContent=" + feedbackContent
				+ ", createDate=" + createDate + ", deleteDate=" + deleteDate
				+ "]";
	}
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFeedbackContent() {
		return feedbackContent;
	}
	public void setFeedbackContent(String feedbackContent) {
		this.feedbackContent = feedbackContent;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

}
