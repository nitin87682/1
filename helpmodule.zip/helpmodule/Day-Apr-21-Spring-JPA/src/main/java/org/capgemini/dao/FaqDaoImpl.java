package org.capgemini.dao;

import java.util.Date;

import java.util.List;

import org.capgemini.pojo.Faq;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class FaqDaoImpl implements IFaqDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void saveFaq(Faq faq) {
		faq.setCreateDate(new Date());
		sessionFactory.getCurrentSession().saveOrUpdate(faq);
		}
	

	@Override
	public List<Faq> GetAllFaq() {
		return sessionFactory.getCurrentSession().createQuery("from Faq").list();
	}

	@Override
	public void deleteFaq(Integer faqId) {
		Faq faq=(Faq) sessionFactory.getCurrentSession().get(Faq.class, faqId);
		faq.setDeleteDate(new Date());
		if(faq!=null)
			sessionFactory.getCurrentSession().delete(faq);
		
		
	}

	@Override
	public Faq SearchFaq(Integer faqId) {
		Faq faq=(Faq) sessionFactory.getCurrentSession().get(Faq.class, faqId);
		return faq;
		
	}
	
	public void updateFaq(Faq faq) {
		faq.setCreateDate(new Date());
		sessionFactory.getCurrentSession().saveOrUpdate(faq);
		}
}
