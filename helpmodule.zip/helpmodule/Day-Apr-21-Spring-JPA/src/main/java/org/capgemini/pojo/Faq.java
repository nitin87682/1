package org.capgemini.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Faq {
	@Id
	@GeneratedValue
	@Column(name = "faq_id")
	private int faqId;
	@Column(name = "faq_question")
	private String faqQuestion;
	@Column(name = "faq_answer")
	private String faqAnswer;
	@Column(name = "create_date")
	private Date createDate;
	@Column(name = "delete_date")
	private Date deleteDate;
	
	
	
	
	public Faq() {
		super();
	}
	public int getFaqId() {
		return faqId;
	}
	public void setFaqId(int faqId) {
		this.faqId = faqId;
	}
	public String getFaqQuestion() {
		return faqQuestion;
	}
	public void setFaqQuestion(String faqQuestion) {
		this.faqQuestion = faqQuestion;
	}
	public String getFaqAnswer() {
		return faqAnswer;
	}
	public void setFaqAnswer(String faqAnswer) {
		this.faqAnswer = faqAnswer;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	@Override
	public String toString() {
		return "Faq [faqId=" + faqId + ", faqQuestion=" + faqQuestion
				+ ", faqAnswer=" + faqAnswer + ", createDate=" + createDate
				+ ", deleteDate=" + deleteDate + "]";
	}
	
		
	
}
