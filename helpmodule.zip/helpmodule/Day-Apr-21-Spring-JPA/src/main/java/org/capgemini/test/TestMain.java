package org.capgemini.test;

import java.util.Date;

import org.capgemini.pojo.Faq;
import org.capgemini.service.FaqServiceImpl;

public class TestMain {
	
	public static void main(String[] args) {
	Faq f = new Faq();
	FaqServiceImpl faqser=new FaqServiceImpl();
	f.setFaqId(4);
	f.setFaqQuestion("what is going on in this class");
	f.setFaqAnswer("coding");
	f.setCreateDate(new Date());
	faqser.saveFaq(f);
	}

}
