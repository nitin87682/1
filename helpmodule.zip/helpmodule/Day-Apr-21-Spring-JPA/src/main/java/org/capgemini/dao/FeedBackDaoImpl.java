package org.capgemini.dao;

import java.util.Date;
import java.util.List;

import org.capgemini.pojo.FeedBack;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class FeedBackDaoImpl implements IFeedBackDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveFeedBack(FeedBack fb) {
		fb.setCreateDate(new Date());
		sessionFactory.getCurrentSession().save(fb);
		
	}

	@Override
	public List<FeedBack> GetAllFeedBack() {
		return sessionFactory.getCurrentSession().createQuery("from FeedBack").list();
	}

	@Override
	public void deleteFeedBack(Integer feedBackId) {
		FeedBack feed=(FeedBack) sessionFactory.getCurrentSession().get(FeedBack.class, feedBackId);
		
		if(feed!=null)
			sessionFactory.getCurrentSession().delete(feed);
		
	}

}
